package com.example.ch6_20210821_collection

import android.util.Log

class TestCollection {
    fun testList(){
        //不可修改的list
        val list = listOf<String>("Ken","Vivin","Lindy")
        Log.d("Howard","Msg:${list.javaClass}")
        list.forEach { Log.d("Howard","value:$it") }
        val nList = mutableListOf<Int>(80,90,100,10,5,7)
        Log.d("Howard","className:${nList.javaClass}")
        nList[1] = 10
        nList.add(25)
        nList.filter { it>20 }.forEach { Log.d("Howard",it.toString()) }
    }

    fun testSet(){

        val set = setOf<Int>(10,50,70,29,50,70,10)
            Log.d("Howard","set class Name:${set.javaClass}")
        set.forEach { Log.d("Howard","Set:${it}") }

        val set2 = mutableSetOf<Int>(32,65,83)
        set2.add(10)
        set2.add(60)
        set2.forEach { Log.d("Howard","it:$it") }
            Log.d("Howard","====================")
        val sortSet =sortedSetOf(9,11,7,1,3,5)
        sortSet.forEach { Log.d("Howard","Sort:$it") }
        val v = 8 in sortSet
        Log.d("Howard","====================")
        val itm1 = Item("B",50)
        val itm2 = Item("A",35)
        val itm3 = Item("C",25)
        val itm4 = Item("F",100)
        val itm5 = Item("G",75)
//        val sortItemSet = sortedSetOf<Item>(object : Comparator<Item> {
//            override fun compare(p0: Item?, p1: Item?): Int {
//                //if (p0 != null && p1 != null) return p0.price - p1.price
//                //!!如果是null會拋出NullPointerException
//                return p0!!.price - p1!!.price
//            }
//        },itm1,itm2,itm3,itm4,itm5)
        val sortItemSet = sortedSetOf<Item>({it1,it2->it1.price - it2.price},
             itm1,itm2,itm3,itm4,itm5)
        sortItemSet.forEach { Log.d("Howard","Item:$it") }

    }

    fun testMap(){
        val map = mapOf<String,Int>("green" to 0x00BF01,
            "red" to 0xBB0011,
            "blue" to 0x0011AA,
        Pair<String,Int>("White",0xFFFFFF))
        Log.d("Howard","Map:${map.javaClass}")
        map.forEach{k,v-> Log.d("Howard","Key:$k Value:$v")}

        val map2 = mutableMapOf<String,Int>("IPad" to 10,"Iphone" to 20,"Ps5" to 15)
        map2["Ps5"] = 900
        map2["Mac Mini"] = 75
        map2.forEach { k, v -> Log.d("Howard","Key:$k value:$v") }
        //Key 是否存在
        val kyein = "Ps5" in map2
        Log.d("Howard","kyein:$kyein")
        val kyein2 = "android" in map2
        Log.d("Howard","kyein2:$kyein2")

    }

}