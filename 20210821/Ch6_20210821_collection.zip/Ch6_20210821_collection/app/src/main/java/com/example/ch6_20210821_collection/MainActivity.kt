package com.example.ch6_20210821_collection

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val tc = TestCollection()
        //tc.testList()
        //tc.testSet()
        tc.testMap()
//        val item1 = Item("A",100)
//        val item2 = Item("A",100)
//        Log.d("Howard","item1:${item1}")
//        Log.d("Howard","equals:${item1 == item2}")

    }
}