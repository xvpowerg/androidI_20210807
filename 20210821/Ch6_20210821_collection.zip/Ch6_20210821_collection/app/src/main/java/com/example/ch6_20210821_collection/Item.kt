package com.example.ch6_20210821_collection

data class Item(var name:String,var price:Int ) {

}