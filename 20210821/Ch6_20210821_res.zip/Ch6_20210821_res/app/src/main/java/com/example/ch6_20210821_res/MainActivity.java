package com.example.ch6_20210821_res;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.my_layout);
        //findViewById 必須在setContentView之後
        Button btn = findViewById(R.id.myBtn);
        Log.d("Howard","Btn:"+btn);
    }
}