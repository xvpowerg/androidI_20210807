package com.example.ch5_20210821_lamdba

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button

class MainActivity : AppCompatActivity() {
        class MyClick : OnClickListener{
            override fun onClick() {
                    Log.d("Howard","Inner class Click!")
            }

        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tc = TestClickListen()
        tc.setOnClick{
            Log.d("Howard","setOnClick")
        }
        val myClick = MyClick()
        tc.setOnClick(myClick)
        //匿名內部類
        tc.setOnClick(object:OnClickListener{

            override fun onClick() {
                Log.d("Howard","匿名 Inner class Click!")
            }

        })

        val testLambda = TestLambda()
        testLambda.test1(20,5,{x:Int,y:Int->(x+y).toFloat()})
        //lambda 必須是最後一個參數
        testLambda.test1(50,20) {
                x, y -> (x-y).toFloat()
        }

        testLambda.test2(3.5F,4.6F,{x,y->x-y}){
            i,k->i*k
        }
        //如果lambda只有一組參數 可使用it縮寫
         testLambda.test3("Ken"){
            it.length
        }



    }
}