package com.example.ch5_20210821_lamdba

import android.util.Log

class TestLambda {

    fun test1(x:Int,y:Int,action:(Int,Int)->Float){
            Log.d("Howard","Test1:${action(x,y)}")
    }

    //測試一組以上的lambda
    fun test2(x:Float,y:Float,
              func1:(Int,Int)->Int,
              func2:(Float,Float)->Float){

        Log.d("Howard","func1:${func1(x.toInt(),y.toInt())}")
        Log.d("Howard","func2:${func2(x,y)}")
    }

    fun test3(s:String,func1:(String)->Int){
        Log.d("Howard","String Func1:${func1(s)}")
    }

}