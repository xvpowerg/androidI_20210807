package com.example.ch5_20210821_lamdba

interface OnClickListener {
    fun onClick();
}