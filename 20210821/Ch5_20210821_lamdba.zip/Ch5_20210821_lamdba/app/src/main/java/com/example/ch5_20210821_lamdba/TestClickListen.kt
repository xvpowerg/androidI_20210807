package com.example.ch5_20210821_lamdba

class TestClickListen {
    // 使用介面
    fun setOnClick(onClickListener: OnClickListener){
        onClickListener.onClick()
    }
    //lambda Unit 表示沒有回傳
    fun setOnClick(onclick: () -> Unit){
        onclick()
    }

}