package com.example.ch5_20210821_kotlin_oo3.testcompanion

class MyStatic {
    companion object{
        fun min(a:Int,b:Int):Int{
            return if (a < b) a else b
        }
        fun max(a:Int,b:Int):Int{
            return if (a > b) a else b
        }
    }
}