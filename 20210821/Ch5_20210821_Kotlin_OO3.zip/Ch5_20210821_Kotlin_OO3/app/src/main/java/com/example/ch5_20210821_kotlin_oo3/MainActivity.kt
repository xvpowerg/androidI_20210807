package com.example.ch5_20210821_kotlin_oo3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.ch5_20210821_kotlin_oo3.exdmethod.firstAlphabet
import com.example.ch5_20210821_kotlin_oo3.override.Person
import com.example.ch5_20210821_kotlin_oo3.override.Student
import com.example.ch5_20210821_kotlin_oo3.testcompanion.MyStatic
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val p = Person("Ken",178.5F)
        val p2 = Person("Ken",178.5F)
        val list =null
        Log.d("Howard","p:"+p)
        //呼叫== 等同呼叫equals
        Log.d("Howard","Equals:${p==p2}")
        //=== 等同java內呼叫==
        Log.d("Howard","p===p2:${p===p2}")
        p.printHeight()

        val st1 = Student("Vivin",158.6F)
        st1.printHeight()
        Log.d("Howard","$st1")

       val msg = "Ken,Vivin,Lindy,Joy".firstAlphabet()
        Log.d("Howard","msg:$msg")

        val min = MyStatic.min(5,8)
        val max = MyStatic.max(15,7)
        Log.d("Howard","Min:$min Max:$max")
    }
}