package com.example.ch5_20210821_kotlin_oo3.override

import android.util.Log
//open 表示name可複寫
open class Person(open var name:String = "",var height:Float = 0.0f) {

//預設方法都是final 不可複寫
   open fun printHeight(){
        Log.d("Howard","Height:$height")
    }
    override fun toString(): String {
        return  "name:$name height:$height"
    }

    //Any? Any 類似java的Object ? 可傳null
    override fun equals(other: Any?): Boolean {

        if (other != null  &&  other is Person){
            return this.height == other.height && this.name == other.name
        }

        return super.equals(other)
    }

}