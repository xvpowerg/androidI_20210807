package com.example.ch5_20210821_kotlin_oo3.override

import android.util.Log

class Student(name:String="",height:Float=0.0f) : Person(name,height) {

    override var name: String = ""
        //等同return "Student:${super.name}"
        get() = "Student:${super.name}"


    override fun printHeight(){
        Log.d("Howard","Student:")
        super.printHeight()
    }
}