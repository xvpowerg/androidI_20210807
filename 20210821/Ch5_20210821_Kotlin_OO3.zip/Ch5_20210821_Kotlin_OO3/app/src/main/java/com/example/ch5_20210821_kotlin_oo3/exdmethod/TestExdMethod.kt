package com.example.ch5_20210821_kotlin_oo3.exdmethod
//擴充函數
fun String.firstAlphabet(): String {
    val nameList = this.split(",")
    return nameList[0]
}