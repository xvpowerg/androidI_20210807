package com.example.ch6_20210821_testnull

data class Fruit(var name:String,var addr:String?,var price:Int) {
}