package com.example.ch6_20210821_testnull

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var f1 = Fruit("Ap",null,10)

        val msg = f1.name.run {
               if (length < 3) "錯誤" else this
        }
        //addr? 表示addr不是null才執行run
        //?: addr是null執行?:的區塊
        f1.addr?.run {
                Log.d("Howard","Addr:$this")
                if (length < 3){
                    "錯誤"
                }else
                     this
        }?:Log.d("Howard","addr Is Null")
        f1.addr!!.run {  }
        if (f1.addr != null){
            f1.addr.run {  }
        }
        Log.d("Howard","f1:$msg")
    }
}