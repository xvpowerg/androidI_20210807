package com.example.ch6_20210821_android_lifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    //onCreate Activity 如果沒被消滅只會呼叫一次
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //初始化元件
        Log.d("Howard","onCreate")
    }

    override fun onRestart() {
        super.onRestart()
        //因為進入過onStop 狀態有些資源已釋放
        //onRestart 重新恢復 往下一個狀態onStart

        Log.d("Howard","onRestart")
    }

    override fun onStart() {
        super.onStart()
        //畫面出現了 無法互動
        //可以做UI的設定
        Log.d("Howard","onStart")
    }

    override fun onResume() {
        super.onResume()
        //畫面的元件可互動
        //加入GPS動作
        //加入藍芽控制
        Log.d("Howard","onResume")
    }

    override fun onPause() {
        super.onPause()
        //離開部分目前畫面 無控制權
        //可以看到部分畫面 尚未完全轉移
        //釋放資源
        //停止GPS動作 藍芽控制
        Log.d("Howard","onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Howard","onStop")
        //完全離開目前畫面 無控制權
        //可將資料寫入到本機端資料庫
        //暫停所以有的控制
    }

    override fun onDestroy() {
        super.onDestroy()
        //釋放資源
        Log.d("Howard","onDestroy")
    }

}