package com.example.ch21_baseadapter;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ch21_baseadapter.beans.Student;

import java.util.ArrayList;

public class StudentInfoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_layout);
        Intent dataIntent = getIntent();
        ListView stList =  findViewById(R.id.studentInfoList);
        Student st =  dataIntent.getParcelableExtra("stobj");
        ArrayList<String> dataStrList = new ArrayList<>();
        dataStrList.add("id:"+st.getId());
        dataStrList.add("name:"+st.getName());
        dataStrList.add("phone:"+st.getPhone());
        dataStrList.add("score:"+st.getScore()+"");
        dataStrList.add("Address:"+st.getAddr());
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                dataStrList);
        stList.setAdapter(arrayAdapter);
    }
}

