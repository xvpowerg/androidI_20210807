package com.example.ch21_baseadapter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.ch21_baseadapter.adpater.MyBaseAdapter;
import com.example.ch21_baseadapter.beans.Student;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private  MyBaseAdapter<Student> stAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<Student> list = new ArrayList<Student>();
        //String id, String name, int score, String addr, String phone
        Student st1 = new Student("100","Ken",78,
                "408 臺中市南屯區向學路11號","04-8825252");
        Student st2 = new Student("101","Vivin",93,
                "907 屏東縣鹽埔鄉永樂路33號","097755122");
        Student st3 = new Student("102","Lucy",85,
                "831 高雄市大寮區正忠街13號","07-5521818");
        list.add(st1);
        list.add(st2);
        list.add(st3);
        ListView listView =  findViewById(R.id.myListView);
        stAd = new MyBaseAdapter<>(this,list);
        listView.setAdapter(stAd);

        listView.setOnItemClickListener((parent,view,position,id)->{
            Log.d("Howard","click parent:"+parent+"\n"+
                    "View:"+view+"\nposition:"+position+"\nid:"+id);
             Student st = (Student)parent.getItemAtPosition(position);
            Intent stIntent = new Intent(this,StudentInfoActivity.class);
            stIntent.putExtra("stobj",st);
            startActivity(stIntent);
        });

        listView.setOnItemLongClickListener((parent,view,position,id)->{
//            Log.d("Howard","Long... parent:"+parent+"\n"+
//                    "View:"+view+"\nposition:"+position+"\nid:"+id);
            //true 呼叫完LongClick 不在呼叫Click
            //false 呼叫完LongClick 會呼叫Click
            return true;
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Random random = new Random();
        int id = random.nextInt(2000);
        switch (item.getItemId()){
            case R.id.add_item:
                Student tmpSt = new Student(id+"","name:"+id,id,"","");
                stAd.addStudent(tmpSt);
                return true;
            case R.id.help:
                Toast.makeText(this, "練習!!", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}