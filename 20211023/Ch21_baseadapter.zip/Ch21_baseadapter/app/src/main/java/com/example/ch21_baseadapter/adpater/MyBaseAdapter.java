package com.example.ch21_baseadapter.adpater;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.ch21_baseadapter.R;
import com.example.ch21_baseadapter.beans.Student;

import java.util.ArrayList;

public class MyBaseAdapter<T extends Student> extends BaseAdapter {
    private ArrayList<T> dataList;
    private Context context;
    public MyBaseAdapter(Context context, ArrayList<T> list){
        this.context = context;
        this.dataList = list;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public T getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        int id = -1;
        id = Integer.parseInt(dataList.get(i).getId());
        return id;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Log.d("Howard","viewGroup:"+viewGroup);
       View layout =  LayoutInflater.from(context).inflate(R.layout.student_list_layout,
                viewGroup,false);
        T data =  getItem(i);
        TextView idText = layout.findViewById(R.id.stIdTxt);
        TextView nameText = layout.findViewById(R.id.stNameTxt);
        idText.setText(data.getId());
        nameText.setText(data.getName());
        return layout;
    }
    public void addStudent(T st){
        dataList.add(st);
        notifyDataSetChanged();
    }
}
