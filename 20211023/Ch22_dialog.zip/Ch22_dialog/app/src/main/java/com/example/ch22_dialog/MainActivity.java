package com.example.ch22_dialog;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MainActivity extends AppCompatActivity {

    private String[] array = {"MacBook Air","MacBook Pro","MacBook Pro Max"};
    private boolean[] selected = {false,true,false};
    private int statusSelected = 1;
        private  void dialogBtn(DialogInterface dialog,int which){
            switch (which){
                case DialogInterface.BUTTON_POSITIVE:
                    Log.d("Howard","POSITIVE");
                    break;
                case DialogInterface.BUTTON_NEGATIVE:
                    Log.d("Howard","NEGATIVE");
                    break;
                case DialogInterface.BUTTON_NEUTRAL:
                    Log.d("Howard","NEUTRAL");
                    break;
            }
        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);

        btn1.setOnClickListener(v->{
            new AlertDialog.Builder(this).
                    setTitle("Title").
                    setMessage("Message").
                    setPositiveButton("確定",this::dialogBtn).
                    setNegativeButton("取消",this::dialogBtn).
                    setNeutralButton("關於我",this::dialogBtn).
                    setCancelable(false).show();
        });
        btn2.setOnClickListener(v->{
            EditText editText = new EditText(this);
        new AlertDialog.Builder(this).
                setTitle("Input").setMessage("請輸入...").
                setView(editText).setPositiveButton("確定",(dialog,which)->{
                String name = editText.getText().toString();
            Toast.makeText(this, name, Toast.LENGTH_SHORT).show();
        }).show();
        });
        btn3.setOnClickListener(v->{
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    new String[]{"Apple","Banana","Kiwi"});
            //setAdapter不可跟setMessage一起使用
            new AlertDialog.Builder(this).setTitle("Title").
                    setAdapter(arrayAdapter,(d,position)->{
                        String msg =   arrayAdapter.getItem(position);
                        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                    }).
                    setPositiveButton("確定",null).show();
        });

        btn4.setOnClickListener(v->{

            int[] selectIndex = {0,1,2};
            new AlertDialog.Builder(this).
                    setMultiChoiceItems(array,selected,(d,position,check)->{
                        selected[position] =  check;
                    }).
                    setPositiveButton("確定",(d,which)->{
                        String msg = IntStream.of(selectIndex).
                                filter(i->selected[i]).mapToObj(i->array[i]).
                                collect(Collectors.joining(","));
                        if (msg.isEmpty()){
                            msg = "無產品!";
                        }
                        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
                    }).show();

//按下勾選後那些產品勾選了
        });

        btn5.setOnClickListener(v->{

            String[] status = {"已婚","未婚","一言難盡"};
            new AlertDialog.Builder(this).setTitle("請選狀態").
                    setSingleChoiceItems(status,statusSelected,(d,index)->{
                        statusSelected = index;
                    }).setPositiveButton("確定",(d,witch)->{
                     Toast.makeText(this, status[statusSelected], Toast.LENGTH_SHORT).show();
            }).show();

        });
        btn6.setOnClickListener(v->{
            View view =
                    getLayoutInflater().inflate(R.layout.dialog_layout,null,false);
            EditText accountTxt =  view.findViewById(R.id.accountTxt);
            EditText passwordTxt  = view.findViewById(R.id.passwordTxt);
           new AlertDialog.Builder(this).setTitle("請登入").setView(view).
                   setCancelable(false).setPositiveButton("登入",(d,w)->{

               String account = accountTxt.getText().toString();
               String password = passwordTxt.getText().toString();
               Log.d("Howard","account:"+account+" password:"+password);

           }).
                   setNegativeButton("取消",null).show();
        });
    }
}