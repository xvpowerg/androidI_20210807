package com.example.ch22_android_async;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;

public class LoopImages {
    private int[] images = {R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4};
    private ImageView imageView;
    private Context context;
    private boolean stopLoop = false;
    //會紀錄new Handler當下的Thread
    private Handler handler = new Handler();
    private int i = 0;
    public LoopImages(Context context, ImageView imageView){
            this.context = context;
            this.imageView = imageView;
    }

    public void startLoop(){
        stopLoop = false;
        for (; i <images.length || (i %=images.length) == 0 ;i++){
            handler.post(()->imageView.setImageResource(images[i]));
            Log.d("Howard","startLoop image id:"+images[i]);
            Log.d("Howard","Thread Name:"+Thread.currentThread());
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch(Exception ex){}
            if (stopLoop){
                break;
            }
        }
    }

    public void stopLoop(){
        stopLoop = true;
    }

}
