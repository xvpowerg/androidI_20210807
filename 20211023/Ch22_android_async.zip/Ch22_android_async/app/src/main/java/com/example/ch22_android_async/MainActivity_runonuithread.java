package com.example.ch22_android_async;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;

public class MainActivity_runonuithread extends AppCompatActivity {
    private boolean runThread = true;

    private void testRunOnUiThread(ImageView imageView,int res){
        this.runOnUiThread(()->{
            imageView.setImageResource(res);
        });
    }

        private int[] images = {R.drawable.image1,
                R.drawable.image2,
                R.drawable.image3,
                R.drawable.image4};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        ImageView imageView =  findViewById(R.id.imageView);



        startBtn.setOnClickListener(v->{
            runThread = true;
            Thread runImageThread = new Thread(()->{
                    for (int i = 0; i <images.length || (i %=images.length) == 0 ;i++){
                        //imageView.setImageResource(images[i]);
                        testRunOnUiThread(imageView,images[i]);
                        Log.d("Howard","image id:"+images[i]);
                        try{
                            TimeUnit.SECONDS.sleep(1);
                        }catch(Exception ex){}
                        if (!runThread){
                            break;
                        }
                    }
            });

            runImageThread.start();
        });

        stopBtn.setOnClickListener(v->{
            runThread = false;

        });
    }
}