package com.example.ch22_android_async;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn = findViewById(R.id.startBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        ImageView imageView =  findViewById(R.id.imageView);
         LoopImages loopImages = new LoopImages(this,imageView);


        startBtn.setOnClickListener(v->{
            Thread loopThread =
                    new Thread(()->loopImages.startLoop());
            loopThread.start();
        });

        stopBtn.setOnClickListener(v-> loopImages.stopLoop());
    }
}