package com.example.ch25_test_gps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private LocationModel locationModel;
    private double lat = 0,lot=0;
    private double toLat = 22.594539, toLot = 120.306133;
    private void addLocationChange(){
        //如果沒開啟任何可以定對裝置
        if(!locationModel.isProviderEnabled()){
            //開啟GPS設定介面
            Intent opGps = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(opGps);
            return;
        }
        locationModel.addListener();
        locationModel.setLocationEvent(location -> {
            lat = location.getLatitude();//緯度
            lot = location.getLongitude();//經度
        });
    }


    private void initGSPPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED ){
            addLocationChange();

        }else{
            ActivityCompat.requestPermissions(this,new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            },100);
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LocationManager locationManager =
                (LocationManager) getSystemService(Context.LOCATION_SERVICE);
         locationModel = new LocationModel(locationManager);

         Button btn = findViewById(R.id.gotoBtn);
        btn.setOnClickListener(v->{
            //目前經緯度  ?q 導航的位置
            String uri = "geo: %s,%s ?q=%s,%s";
            uri = String.format(uri,lat+"",lot+"",toLat,toLot+"");
            Intent gotoIntent = new Intent(Intent.ACTION_VIEW,Uri.parse(uri));
            startActivity(gotoIntent);
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED ||
                grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            addLocationChange();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initGSPPermission();
    }

    @Override
    protected void onPause() {
        super.onPause();
        locationModel.removeListener();
    }
}