package com.example.ch25_test_gps;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import java.util.List;

public class LocationModel {
    private LocationManager locationManager;
    private LocationChangeEvent locationEvent;
    private   MyLocationListener myLocationListener;
    public interface LocationChangeEvent{
            void action( Location location);
    }
    private  class MyLocationListener implements LocationListener {

        @Override
        public void onLocationChanged(@NonNull Location location) {
                //位置轉換
            double lat=  location.getLatitude();
            double lot  = location.getLongitude();
            Log.d("Howard","lat:"+lat+"lot:"+lot);
            if (locationEvent != null){
                locationEvent.action(location);
            }
        }

        @Override
        public void onProviderDisabled(@NonNull String provider) {

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }
    }

    public void setLocationEvent(LocationChangeEvent locationEvent){
        this.locationEvent = locationEvent;
    }

    public LocationModel(LocationManager locationManager) {
        this.locationManager = locationManager;

    }

    @SuppressLint("MissingPermission")
    public void addListener() {
        if (myLocationListener == null){
            myLocationListener = new MyLocationListener();
        }

        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L,
                0f,  myLocationListener);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000L,
                0f,  myLocationListener);
    }

    public void removeListener(){
            if (myLocationListener != null){
                locationManager.removeUpdates(myLocationListener);
            }

            myLocationListener = null;
    }
    //測試裝置是否有開啟
    public boolean isProviderEnabled(){
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ;
    }

}
