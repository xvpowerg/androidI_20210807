package com.example.ch26_maskproject.bean;

public class Feature {
    private  Properties properties;
    private   Geometry geometry;

    public Properties getProperties() {
        return properties;
    }

    public Geometry getGeometry() {
        return geometry;
    }
}

