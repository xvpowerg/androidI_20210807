package com.example.ch26_maskproject.bean;

import java.util.ArrayList;

public class MaskData {
    private ArrayList<Feature> features;
        public ArrayList<Feature> getFeatures(){
            return features;
        }
}
