package com.example.ch26_maskproject.bean;

import java.util.ArrayList;

public class Geometry {
    private ArrayList<Double> coordinates;
    public double getLon(){return coordinates.get(0);}
    public double getLat(){return coordinates.get(1);}
}
