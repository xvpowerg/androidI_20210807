package com.example.ch26_maskproject.json;

import android.util.Log;

import com.example.ch26_maskproject.bean.MaskData;
import com.google.gson.Gson;

import java.util.function.Consumer;

public class MaskJsonTools {

    public static void jsonToObject(String maskJson, Consumer<MaskData> callBack){
        Gson gson = new Gson();
        Thread thread = new Thread(()->{
            MaskData maskData =
                    gson.fromJson(maskJson,MaskData.class);
            Log.d("Howard","maskData:"+maskData);
            callBack.accept(maskData);

        });
        thread.start();
    }
}
