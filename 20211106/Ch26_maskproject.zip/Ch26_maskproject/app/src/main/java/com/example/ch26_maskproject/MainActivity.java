package com.example.ch26_maskproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.ch26_maskproject.adapter.MaskAdapter;
import com.example.ch26_maskproject.json.MaskJsonTools;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private class OkHttpCallBack implements Callback {

        @Override
        public void onFailure(@NonNull Call call, @NonNull IOException e) {
            Log.e("Howard","onFailure:"+e);
        }

        @Override
        public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
            String json = response.body().string();
            MaskJsonTools.jsonToObject(json,(maskData)->{
//                Log.d("Howard","json to obj call back!!:"+
//                        maskData.getFeatures().get(0).getProperties());
                runOnUiThread(()->{
                    MaskAdapter maskAdapter = new MaskAdapter( maskData.getFeatures());
                    listView.setAdapter(maskAdapter);

                });

            });
            Log.d("Howard","json:"+json);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        String url = "https://raw.githubusercontent.com/kiang/pharmacies/master/json/points.json";
        OkHttpClient.Builder okb = new OkHttpClient.Builder();
        OkHttpClient okHttpClient =
                okb.retryOnConnectionFailure(true).
                        readTimeout(10, TimeUnit.SECONDS).build();
        Request.Builder rb = new Request.Builder();
        Request request = rb.url(url).build();
        okHttpClient.newCall(request).enqueue(new OkHttpCallBack());


         listView = findViewById(R.id.maskList);

    }
}