package com.example.ch26_maskproject.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.ch26_maskproject.R;
import com.example.ch26_maskproject.bean.Feature;
import com.example.ch26_maskproject.bean.Properties;

import org.w3c.dom.Text;

import java.util.List;

public class MaskAdapter  extends BaseAdapter {
    private List<Feature> featureList;
    public MaskAdapter(List<Feature> featureList){
        this.featureList = featureList;
    }
    @Override
    public int getCount() {
        return featureList.size();
    }

    @Override
    public Feature getItem(int position) {
        return featureList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.mask_adapter_layout,parent,false);
        TextView nameText =  view.findViewById(R.id.name);
        TextView count1Text = view.findViewById(R.id.count1);
        TextView count2Text =view.findViewById(R.id.count2);
        Feature feature =  getItem(position);
        Properties p = feature.getProperties();
        nameText.setText(p.getName());
        count1Text.setText(p.getMask_adult()+"");
        count2Text.setText(p.getMask_child()+"");
        return view;
    }
}
