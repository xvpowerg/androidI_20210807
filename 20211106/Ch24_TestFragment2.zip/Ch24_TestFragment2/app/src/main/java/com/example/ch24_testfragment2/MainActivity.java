package com.example.ch24_testfragment2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.ch24_testfragment2.viewmode.MainViewModel;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      ButtonFragment buttonFragment =
              (ButtonFragment)getSupportFragmentManager().findFragmentById(R.id.btnFragment);
        ImageFragment imageFragment =
                (ImageFragment)getSupportFragmentManager().findFragmentById(R.id.imageFragment);
        MainViewModel mainViewModel = new MainViewModel(imageFragment);
        Log.d("Howard","imageFragment:"+imageFragment);
        buttonFragment.initBtnOnclick(mainViewModel::click);
    }
}