package com.example.ch24_testfragment2.viewmode;

import android.view.View;

import com.example.ch24_testfragment2.ImageFragment;
import com.example.ch24_testfragment2.R;

public class MainViewModel {
    private ImageFragment imageFragment;
    public MainViewModel(ImageFragment imageFragment){
            this.imageFragment =  imageFragment;
    }

    int res =0;
    public void click(View view){
        int btnId = view.getId();
        switch(btnId){
            case R.id.image1Btn:
                res = R.drawable.image1;
                break;
            case R.id.image2Btn:
                res = R.drawable.image2;
                break;
            case R.id.image3Btn:
                res = R.drawable.image3;
                break;
        }
        imageFragment.changeImage(imv->{
            imv.setImageResource(res);
        });
    }
}
