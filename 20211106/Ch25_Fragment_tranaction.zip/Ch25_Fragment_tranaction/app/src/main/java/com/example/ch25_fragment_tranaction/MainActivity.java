package com.example.ch25_fragment_tranaction;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
        private Fragment fragmentA,fragmentB,fragmentC;
        private void click(View view){
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            switch (view.getId()){
                case R.id.pageABtn:
                    ft.replace(R.id.fragment_container,fragmentA).addToBackStack("fragmentGroup");
                    Log.d("Howard","PageABtn");
                    ft.commit();
                    break;
                case R.id.pageBBtn:
                    ft.replace(R.id.fragment_container,fragmentB).addToBackStack("fragmentGroup");
                    Log.d("Howard","PageBBtn");
                    ft.commit();
                    break;
                case R.id.pageCBtn:
                    ft.replace(R.id.fragment_container,fragmentC).addToBackStack("fragmentGroup");
                    Log.d("Howard","PageCBtn");
                    ft.commit();
                    break;
            }
        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragmentA = new FragmentA();
        fragmentB = new FragmentB();
        fragmentC = new FragmentC();

        Button b1 = findViewById(R.id.pageABtn);
        Button b2 = findViewById(R.id.pageBBtn);
        Button b3 = findViewById(R.id.pageCBtn);
        b1.setOnClickListener(this::click);
        b2.setOnClickListener(this::click);
        b3.setOnClickListener(this::click);

    }
}