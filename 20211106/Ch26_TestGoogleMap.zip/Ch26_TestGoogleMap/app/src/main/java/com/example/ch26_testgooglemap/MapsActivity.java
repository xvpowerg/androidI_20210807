package com.example.ch26_testgooglemap;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.ch26_testgooglemap.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);

        btn1.setOnClickListener(v->{
            LatLng latLng = new LatLng(22.652908, 120.319329);
            //最大深度21
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,17f),
                    2000,null);
        });
        btn2.setOnClickListener(v->{
            MarkerOptions mark = new MarkerOptions();
            MarkerOptions mark2 = new MarkerOptions();
            MarkerOptions mark3 = new MarkerOptions();

            BitmapDescriptor db  = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW);
            BitmapDescriptor food  = BitmapDescriptorFactory.fromResource(R.mipmap.food);

            LatLng latLng = new LatLng(22.652908, 120.319329);
            LatLng latLng2 = new LatLng(22.653544, 120.321988);
            LatLng latLng3 = new LatLng(  22.652099, 120.319976);

            mark.title("家樂福!");
            mark.position(latLng);
            mark2.title("肉圓!");
            mark2.position(latLng2);
            mark2.icon(db);

            mark3.position(latLng3);
            mark3.title("鬥牛火鍋");
            mark3.icon(food);

            mMap.addMarker(mark);
            mMap.addMarker(mark2);
            mMap.addMarker(mark3);
        });
        btn3.setOnClickListener(v->{
            //mMap.setMapType(GoogleMap.MAP_TYPE_NONE);
     //       mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
      //         mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
       //     mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
           mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        });
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng( 22.625471649633063, 120.3181355412114);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        UiSettings uiSet = mMap.getUiSettings();
        uiSet.setZoomControlsEnabled(true);
        uiSet.setTiltGesturesEnabled(true);
    }
}