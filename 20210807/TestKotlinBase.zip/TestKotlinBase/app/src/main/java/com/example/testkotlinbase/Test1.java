package com.example.testkotlinbase;

public class Test1 {
        int[] array = new int[10];
    public  static void testRun(){
        int value = 10;


    }
}
