package com.example.testkotlinbase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //test2()
        //test3()
        //test4(6)
       // test5(5.6f)
//        var msg = test6(48)
//        Log.d("Howard",msg)
       // test7(7)
        //test8()
        //test9()
        //test10()
        //test11()
        //test12()
        test13()
    }

    fun test13(){
        val names = arrayOf("Ken","Vivin","Lindy")
        names[1] = "Lucy"
        for (i in 0 until names.size){
              Log.d("Howard","$i : ${names[i]}")
        }
        for (v in names){
            Log.d("Howard","value:$v")
        }
        Log.d("Howard","===================")
        names.forEach {
            Log.d("Howard","value:$it")
        }
        Log.d("Howard","===================")
        names.forEachIndexed{
            i,e-> Log.d("Howard","i:$i e:$e")
        }
        Log.d("Howard","===================")
    }

    fun test12(){
       bye@ for (i in 1 .. 5){
            Log.d("Howard","======================")
            for (k in 1 .. 3 ){
                  if (i ==2) break@bye
              Log.d("Howard","$i:$k")
            }
            Log.d("Howard","======================")
        }
    }

    fun test11(){
            for (i in 1..10){
                if(i==6){
                    //break
                    continue
                }
                Log.d("Howard","i:$i")
            }
    }

    fun test10(){
        var count = 1
        var end = 10

        while (count < end){
            Log.d("Howard","count:$count")
            count *= 2
        }
    }

    fun test9(){
//        for (n in 0..20 step  2){
//            Log.d("Howard","n:$n")
//        }
        for (n in 20 downTo 1 step  2){
                Log.d("Howard","downTo:$n")
        }
        val len = 5
        for (i in 0 until  len){
            Log.d("Howard","len:$i")
        }
    }
    fun test8(){
        val n = 7
        for (i in 1 .. n){
            Log.d("Howard","i:$i")
        }

        val range = 1..5
            for (x in range){
                Log.d("Howard","x:$x")
            }

    }
    fun test7(month:Int){
        val season = when(month){
            in 3..5->"春"
            in 6..8-> "夏"
            in 9..11->"秋"
            12,1,2->"冬"
            else->"住在火星"
        }
        Log.d("Howard",season)
        //3 4 5 春
        //6 7 8 夏
        //9 10 11 秋
        // 12 1 2 冬
        //住在火星
    }
    fun test6(age :Int):String{
//        return when{
//                age >= 0 && age <18 ->"未成年"
//                age >=18 && age < 65 ->"成年"
//                age >=65 && age < 300 ->"老年"
//                else->"仙人"
//            }

        return when(age){
            in 0..17->"未成年"
            in 18..64->"成年"
            in 65..300 ->"老年"
            else->"仙人"
        }
    }

    fun test5(any:Any){
        when(any){
            is String ->{Log.d("Howard","我是字串:$any")}
            is Int->Log.d("Howard","我是整數:$any")
            else -> Log.d("Howard","Error!")
        }
    }

    fun test4(action:Int){
            when(action){
                1->{Log.d("Howard","Jump")}
                2->{Log.d("Howard","Fly")}
                else ->{
                    Log.d("Howard","錯誤!")
                }
            }
    }

    fun test3(){
            var score = 85
            var msg = if (score >= 60){
                Log.d("Howard","Pass")
                "Pass:$score"
            }else{
                Log.d("Howard","FAIL")
                "FAIL:$score"
            }
        Log.d("Howard",msg)
        }

    fun test2(){
        val age:Int = 10
        val name:String = "Ken"
        val msg = "Name:$name Age:$age"
        Log.d("Howard",msg)

        val v1 = 20
        val v2 = 10
        val msg2 = "ans:$v1/$v2"
        Log.d("Howard",msg2)
        val msg3 = "ans:${v1/v2}"
        Log.d("Howard",msg3)
        val filePath = """C:\myfile\vlaue.txt"""
        Log.d("Howard",filePath)
        val context = """A B C　
            B C \n D
            E F G
        """
        Log.d("Howard",context)
        //字串轉型
        var n1 = "123".toInt()
        Log.d("Howard","n1:$n1")
    }


    fun test1(){
        var height:Float = 175.3f
        var age:Int = 28
        Log.d("Howard","Height:"+height+"Age:"+age)
        val value1:String = "Test!" //常數
        Log.d("Howard","value1:"+value1)
    }



}