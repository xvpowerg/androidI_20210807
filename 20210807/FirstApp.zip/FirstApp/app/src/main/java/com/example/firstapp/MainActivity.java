package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private class MyClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            Log.d("Howard","MyClick!!");
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =  findViewById(R.id.showMsg);
        //MyClick myClick = new MyClick();
        //btn.setOnClickListener(myClick);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"onClick Msg",Toast.LENGTH_SHORT).show();
            }
        });
    }
}