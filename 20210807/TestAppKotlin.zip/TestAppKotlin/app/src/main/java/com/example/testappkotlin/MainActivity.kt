package com.example.testappkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var myButton = findViewById<Button>(R.id.myButton)
        myButton.setOnClickListener {
            Log.d("Howard","Test!!")
        }

        var t1 = TestClass()
        t1.setName("Ken")
        Log.d("Howard",t1.toString())
    }
}