package com.example.testappkotlin;

public class TestClass {

    private String name;
    public void setName(String name){
        this.name = name;
    }
    public String toString(){
        return this.name;
    }
}
