package com.example.ch14_1_ordersystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.example.ch14_1_ordersystem.view.OrderViewModel;

public class MainActivity extends AppCompatActivity {

    private OrderViewModel oredrNodel;

    private void init(){
        CheckBox item1CheckBox = findViewById(R.id.item1Box);
        CheckBox item2CheckBox = findViewById(R.id.item2Box);
        CheckBox item3CheckBox = findViewById(R.id.item3Box);

        EditText textCount1 = findViewById(R.id.item1Count);
        EditText textCount2 = findViewById(R.id.item2Count);
        EditText textCount3 = findViewById(R.id.item3Count);
        RadioGroup  categoryGroup = findViewById(R.id.categoryGroup);


        CheckBox[] boxArray = {item1CheckBox,
                item2CheckBox,
                item3CheckBox};
        EditText[] countArray = {textCount1,
                textCount2,
                textCount3};
        Button submitBtn =  findViewById(R.id.submitBtn);

         oredrNodel = new OrderViewModel(this,
                 boxArray,countArray,categoryGroup,submitBtn);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        oredrNodel.setSubmitBtnOnClickListener(ord->{
            ord.readItem(item -> {
                Log.d("Howard","Item:"+item);
            });
            Log.d("Howard","Category:"+ord.getCategoryStr());

        });

    }
}