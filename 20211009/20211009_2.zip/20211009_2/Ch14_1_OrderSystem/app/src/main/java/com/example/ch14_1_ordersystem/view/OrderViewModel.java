package com.example.ch14_1_ordersystem.view;

import android.content.Context;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.example.ch14_1_ordersystem.R;
import com.example.ch14_1_ordersystem.bean.Item;
import com.example.ch14_1_ordersystem.bean.Order;

public class OrderViewModel {
    private Context context;
    private CheckBox[] checkBoxItems;
    private EditText[] count;
    private Button submitBtn;
    private String[]  items ;
    private  int[] prices;
    private String[] categorys;
    private RadioGroup categoryGroup;
    private Order.Category orderCategory =
                    Order.Category.Internal;//預設為內用
    public OrderViewModel(Context context,
                          CheckBox[] checkBoxItems,
                          EditText[] count,
                          RadioGroup categoryGroup,
                          Button submitBtn){
        this.context = context;
        this.checkBoxItems = checkBoxItems;
        this.count = count;
        this.submitBtn =submitBtn;
        this.categoryGroup = categoryGroup;
        initCheckBox();
        initCategoryGroup();
    }

    private void initCheckBox(){
       items = context.getResources().getStringArray(R.array.items);
       prices = context.getResources().getIntArray(R.array.price);
        String c1 = context.getResources().getString(R.string.category1);
        String c2 = context.getResources().getString(R.string.category2);
        categorys= new String[]{c1,c2};

        String itemsStrFm =context.getString(R.string.item_string_fm);
        for(int i = 0;i < checkBoxItems.length;i++){
            checkBoxItems[i].setText(String.format(itemsStrFm,items[i],prices[i]));
        }
    }

    private void initCategoryGroup(){
        categoryGroup.setOnCheckedChangeListener((group,id)->{
            switch (id){
                case R.id.category1:
                    orderCategory = Order.Category.Internal;
                    break;
                case R.id.category2:
                    orderCategory = Order.Category.Takeout;
                    break;
            }

        });
    }

    public interface SubmitBtnOnClickListener{
        void onclick(Order order);
    }
    public void setSubmitBtnOnClickListener(SubmitBtnOnClickListener submitBtnOnClickListener){
        submitBtn.setOnClickListener(v->{
            Order order = new Order(categorys);
            order.setCategory(orderCategory);

                for (int i  = 0; i <checkBoxItems.length ;i++){
                    //String name, int count, int price
                    if (checkBoxItems[i].isChecked()){
                        String name = items[i];
                        int price = prices[i];
                        String countStr = count[i].getText().toString();
                        int itemCount = 0;
                        try{
                            itemCount = Integer.parseInt(countStr);
                        }catch (Exception ex){ }
                        Item item = new Item(name,itemCount,price);
                        order.addItem(item);
                    }
                }

            //order.setCategory();
            submitBtnOnClickListener.onclick(order);

        });
    }



}
