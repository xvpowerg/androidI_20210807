package com.example.ch14_1_ordersystem.bean;

import java.util.ArrayList;
import  java.util.function.Consumer;
public class Order {
    private ArrayList<Item> items = new ArrayList<>();
    private Category category;
    private String[] categoryStrs;
    public enum Category{
        Internal,
        Takeout
    }
    public Order(){ }
    public Order(String[] categoryStrs){
        this.categoryStrs = categoryStrs;
    }
    public void readItem(Consumer<Item> consumer){
        items.forEach(consumer);
    }
    //複製一份Item
    //深度copy
    public ArrayList<Item> getItem(){
        ArrayList<Item> copyList = new ArrayList();
        for (Item  tmpItem  : items){
            copyList.add((Item)tmpItem.clone());
        }
        return copyList;
    }

    public void addItem(Item item){
        items.add(item);
    }

    public void setCategory(Category category){
        this.category = category;
    }

    public Category getCategory(){
        return category;
    }

    public String getCategoryStr(){
        return categoryStrs[category.ordinal()];
    }

}
