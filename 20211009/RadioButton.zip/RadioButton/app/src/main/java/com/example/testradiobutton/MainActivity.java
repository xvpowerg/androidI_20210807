package com.example.testradiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private String msg = "";
    private HashMap<Integer,String> rbMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup rg = findViewById(R.id.statusGroup);
        Button btn = findViewById(R.id.submitButton);

        msg = getString(R.string.status1);
        rbMap.put(R.id.status1RB,getString(R.string.status1));
        rbMap.put(R.id.status2RB,getString(R.string.status2));
        rbMap.put(R.id.status3RB,getString(R.string.status3));

        rg.setOnCheckedChangeListener((group,id)->{

            msg =rbMap.get(id);
        });

        btn.setOnClickListener(v->{
            Toast.makeText( this,msg, Toast.LENGTH_SHORT).show();

        });

    }
}