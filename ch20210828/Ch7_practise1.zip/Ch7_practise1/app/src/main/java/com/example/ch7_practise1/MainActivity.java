package com.example.ch7_practise1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText n1Ed = findViewById(R.id.n1EdTxt);
        EditText n2Ed = findViewById(R.id.n2EdTxt);
        TextView answerView = findViewById(R.id.ansTxt);
        Button btn = findViewById(R.id.addBtn);

        btn.setOnClickListener(v->{
            String n1String = n1Ed.getText().toString();
            String n2String = n2Ed.getText().toString();
            int value1 = Integer.parseInt(n1String);
            int value2 = Integer.parseInt(n2String);
            int asn = value1 + value2;
            answerView.setText(asn+"");
        });


    }
}