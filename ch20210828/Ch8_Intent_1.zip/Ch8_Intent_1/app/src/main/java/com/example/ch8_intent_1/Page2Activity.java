package com.example.ch8_intent_1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity extends AppCompatActivity {
    private void toPage3(View view){
        Intent toPage3 = new Intent(this,Page3Activity.class);
        startActivity(toPage3);
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_layout);
        Log.d("Howard","Page2 onCreate");
        Button btn = findViewById(R.id.page2Btn);
        btn.setOnClickListener(this::toPage3);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard","Page2 onCreate");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","Page2 onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","Page2 onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","Page2 onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","Page2 onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","Page2 onDestroy");
    }
}
