package com.example.ch8_intent_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page3Activity  extends AppCompatActivity {
            private void click(View view){
//                Intent toPage2 = new Intent(this,Page2Activity.class);
//                startActivity(toPage2);
                finish();
            }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page3_layout);
        Button btn =  findViewById(R.id.page3Btn);
        btn.setOnClickListener(this::click);
    }
}
