package com.example.ch8_2_rotation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private TextView msgTxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            Button btn = findViewById(R.id.setTxtBtn);
                //Use lambda in  onclick set TextView  is txt change to "Page1"
        Log.d("Howard","onCreate:"+savedInstanceState);


        msgTxt = findViewById(R.id.textView);
        msgTxt.setOnClickListener(v->{
            if (v instanceof  TextView){
                String msg =
                        ((TextView) v).getText().toString();
                Log.d("Howard","msg:"+msg);
            }

        });
        btn.setOnClickListener(v->{
            msgTxt.setText("Page1");
        });


        if (savedInstanceState != null){
            msgTxt.setText(savedInstanceState.getString("msg"));
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard","onRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("msg",msgTxt.getText().toString());
        Log.d("Howard","onSaveInstanceState");
    }
}