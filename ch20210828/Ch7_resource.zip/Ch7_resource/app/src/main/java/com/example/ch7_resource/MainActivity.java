package com.example.ch7_resource;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int count = 0;
    private int[]  images = {R.drawable.image1,R.drawable.image2,R.drawable.image3};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView msgTextView = findViewById(R.id.msgTextView);
        TextView msgTextView2 =   findViewById(R.id.msgTextView2);
        ImageView image2 =  findViewById(R.id.imageView2);
        image2.setImageResource(R.drawable.image1);

        msgTextView.setText(R.string.msg1);
        String msg2 = getString(R.string.msg2);
        msg2 =  String.format(msg2,"Ken");
        msgTextView2.setText(msg2);

        image2.setOnClickListener(v->{
            count++;
            if (count == 3) count = 0;
            image2.setImageResource(images[count]);
        });




    }
}