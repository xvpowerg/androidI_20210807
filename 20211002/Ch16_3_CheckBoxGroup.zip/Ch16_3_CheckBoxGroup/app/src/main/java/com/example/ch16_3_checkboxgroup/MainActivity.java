package com.example.ch16_3_checkboxgroup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button saveBtn = findViewById(R.id.saveBtn);
        Button checkBoxBtn = findViewById(R.id.genCheckBox);
        EditText checkCountEdit = findViewById(R.id.checkCount);
        ViewGroup  viewGroup = findViewById(R.id.checkBoxGroup);

        checkBoxBtn.setOnClickListener(v->{
            viewGroup.removeAllViews();
            String countTxt = checkCountEdit.getText().toString();
                int count = Integer.parseInt(countTxt);
                for (int i = 1;i<=count;i++){
                    CheckBox box = new CheckBox(this);
                    box.setText("Box"+i);
                    viewGroup.addView(box);
                }
        });

        saveBtn.setOnClickListener(v->{
            for (int i = 0;i < viewGroup.getChildCount();i++){
                   View view =  viewGroup.getChildAt(i);
                   if (view instanceof  CheckBox){
                       CheckBox box = ((CheckBox) view);
                       if (box.isChecked()){
                            Log.d("Howard","box:"+box.getText());
                       }
                   }
            }
        });
    }
}