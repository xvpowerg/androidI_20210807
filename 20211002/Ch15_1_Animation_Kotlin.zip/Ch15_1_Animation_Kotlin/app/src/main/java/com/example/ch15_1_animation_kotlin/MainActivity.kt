package com.example.ch15_1_animation_kotlin

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import com.example.ch15_1_animation_kotlin.databinding.ActivityMainBinding
import com.example.ch15_1_animation_kotlin.databinding.DetailLayoutBinding
import android.util.Pair

class MainActivity : AppCompatActivity() {
private lateinit var binding : ActivityMainBinding;
    private fun showDetail(view:View){
            val intent = Intent(this,
                                DetailActivity::class.java)
        var flag:String="explode"
        var type = 0
        val imagePair:Pair<View,String> =
            Pair(binding.titleView,getString(R.string.imageTransition))
        val textPair:Pair<View,String> = Pair(view,getString(R.string.textTransition))
        val tansAnimation = ActivityOptions.makeSceneTransitionAnimation(this,
            imagePair, textPair)

        when(view.id){
            R.id.btn1->{
                type = 0
                flag = "explode"
            }

            R.id.btn2 ->{
                type = 1
                flag = "explode"
            }
            R.id.btn3 ->{
                type = 2
                flag = "slide"
            }
            R.id.btn4 ->{
                type = 3
                flag = "fade"
            }
        }
        intent.putExtra("type",type)
        intent.putExtra("flag",flag)
        startActivity(intent,tansAnimation.toBundle())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //binding.btn1.setOnClickListener()
//        var btn1 = findViewById<Button>(R.id.btn1)
//        var btn2 = findViewById<Button>(R.id.btn2)
//        var btn3 = findViewById<Button>(R.id.btn3)
//        var btn4 = findViewById<Button>(R.id.btn4)
//
        binding.btn1.setOnClickListener(this::showDetail)
        binding.btn2.setOnClickListener(this::showDetail)
        binding.btn3.setOnClickListener(this::showDetail)
        binding.btn4.setOnClickListener(this::showDetail)

    }
}