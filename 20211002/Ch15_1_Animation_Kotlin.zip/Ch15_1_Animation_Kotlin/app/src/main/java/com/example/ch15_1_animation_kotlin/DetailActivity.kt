package com.example.ch15_1_animation_kotlin

import android.os.Bundle
import android.transition.Explode
import android.transition.Fade
import android.transition.Slide
import android.transition.Transition
import android.view.Window
import androidx.appcompat.app.AppCompatActivity
import com.example.ch15_1_animation_kotlin.databinding.DetailLayoutBinding

class DetailActivity : AppCompatActivity()  {
    private lateinit var infos:Array<String>
    private val images = intArrayOf(R.drawable.image1,
        R.drawable.image2,
        R.drawable.image3,
        R.drawable.image4)

    private fun setupTransition(flag:String?){
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        var transition :Transition = Explode()

        when(flag){
            "explode"->{
                transition = Explode()
            }
            "slide"->{
                transition = Slide()
            }
            "fade"->{
                transition = Fade()
            }
        }

        transition.duration = 1000
        window.enterTransition = transition
        window.exitTransition = transition


    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val type = intent.getIntExtra("type",0)
        val  flag = intent.getStringExtra("flag")
        setupTransition(flag)

          val binding = DetailLayoutBinding.inflate(layoutInflater)
          setContentView(binding.root)
          infos = resources.getStringArray(R.array.detail)

        binding.roleImageView.setImageResource(images[type])
        binding.infoText.text = infos[type]
    }
}