package com.example.ch16_ckeckbox1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private ArrayList<CheckBox> checkBoxList = new ArrayList();
    private ArrayList<String> list = new ArrayList();
    private Set<String> dataSet = new HashSet<>();
    private void checkBoxMethd(CompoundButton var1, boolean isCheck){
        String text = var1.getText().toString();
            if (isCheck){
                dataSet.add(text);
            }else{
                dataSet.remove(text);
            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         CheckBox item1box =  findViewById(R.id.item1Box);
         CheckBox item2box =  findViewById(R.id.item2Box);
         CheckBox item3box =  findViewById(R.id.item3Box);
        checkBoxList.add(item1box);
        checkBoxList.add(item2box);
        checkBoxList.add(item3box);
//        item1box.setOnCheckedChangeListener(this::checkBoxMethd);
//        item2box.setOnCheckedChangeListener(this::checkBoxMethd);
//        item3box.setOnCheckedChangeListener(this::checkBoxMethd);

         Button saveBtn= findViewById(R.id.saveBtn);
            saveBtn.setOnClickListener(v->{
                //Log.d("Howard",dataSet.toString());
                for (CheckBox box : checkBoxList){
                    if (box.isChecked())Log.d("Howard",box.getText().toString());
                }

            });

    }
}