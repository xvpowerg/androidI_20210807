package com.example.ch16_2_checkboxall;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {
    private CheckBox allCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        allCheckBox = findViewById(R.id.sellectAllBox);
        CheckBox item1box =  findViewById(R.id.item1Box);
        CheckBox item2box =  findViewById(R.id.item2Box);
        CheckBox item3box =  findViewById(R.id.item3Box);
        ArrayList<CheckBox> list = new ArrayList<>();
        list.add(item1box);
        list.add(item2box);
        list.add(item3box);
        allCheckBox.setOnClickListener((box)->{
            CheckBox checkBox = (CheckBox)box;
            boolean isCheck = checkBox.isChecked();
            for (CheckBox subBox : list){
                subBox.setChecked(isCheck);
            }
        });

        CompoundButton.OnCheckedChangeListener onCheckedChangeListener = (box,isCheck)->{
            if (!isCheck){
                allCheckBox.setChecked(false);
            }else{
                boolean isSelectAll =
                        list.stream().allMatch(c->c.isChecked());
                if (isSelectAll) allCheckBox.setChecked(true);
            }
        };

        for (CheckBox box : list){
            box.setOnCheckedChangeListener(onCheckedChangeListener);
        }

        Button btn = findViewById(R.id.saveBtn);
        btn.setOnClickListener(v->{

            String value = list.stream().filter(c->c.isChecked()).
                    map(c->c.getText().toString()).
                    collect(Collectors.joining(","));
            Log.d("Howard","value:"+value);

        });



    }
}