package com.example.ch23_testnotification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private final String CHANNEL_ID = "msgID";
    private int count = 0;
    private void createNotificationChannel(){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

                NotificationManager nm =
                        (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel channel =  nm.getNotificationChannel(CHANNEL_ID);
                if (channel != null){
                    return;
                }
                String name = "TestNotifiName";
                String desName = "TestNotifi Des ";
                int importance = NotificationManager.IMPORTANCE_DEFAULT;
                NotificationChannel nchannel = new NotificationChannel(CHANNEL_ID,name,importance);
                nchannel.setDescription(desName);
                nm.createNotificationChannel(nchannel);
            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 =  findViewById(R.id.notifiBtn1);
        Button btn2 =  findViewById(R.id.notifiBtn2);
        Button btn3 =  findViewById(R.id.notifiBtn3);
        Button btn4 =  findViewById(R.id.notifiBtn4);
        createNotificationChannel();
        btn1.setOnClickListener(v->{
            NotificationCompat.Builder nb =
                    new NotificationCompat.Builder(this,CHANNEL_ID);
            nb.setSmallIcon(R.drawable.ic_baseline_add_alert_24);
            nb.setContentTitle("Title");
            nb.setContentText("OLED版機種熱賣、提振任天堂(Nintendo)Switch系列機種(一般版Switch+小型廉價版機種Switch" +
                    " Lite+OLED版Switch)上週日本銷售量暴增5成，而Sony PS5系列機種(搭載光碟機的標準版+未搭載光碟" +
                    "機的數位版)銷售量則大減約2成。\n" +
                    "日本遊戲總合情報媒體Famitsu 28日晚間公布統計數據指出，因OLED版機種熱賣，帶動上週" +
                    "(10月18-24日)Switch系列機種日本銷售量較上上週(10月11-17日)暴增近5成(暴增48%)至10萬8,122台。");
            nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
            int id = 1;
            NotificationManagerCompat.from(this).notify(id,nb.build());

        });

        btn2.setOnClickListener(v->{
            int id = 2;
            NotificationCompat.Builder nb = new NotificationCompat.Builder(this,CHANNEL_ID);
            nb.setSmallIcon(R.drawable.msg2);
            nb.setContentText("Big Text");
            NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle().
                    bigText("OLED版機種熱賣、提振任天堂(Nintendo)Switch系列機種(一般版Switch+小型廉價版機種Switch" +
                            " Lite+OLED版Switch)上週日本銷售量暴增5成，而Sony PS5系列機種(搭載光碟機的標準版+未搭載光碟" +
                            "機的數位版)銷售量則大減約2成。\n" +
                            "日本遊戲總合情報媒體Famitsu 28日晚間公布統計數據指出，因OLED版機種熱賣，帶動上週" +
                            "(10月18-24日)Switch系列機種日本銷售量較上上週(10月11-17日)暴增近5成(暴增48%)至10萬8,122台。");
            nb.setStyle(bigTextStyle);
            nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
           NotificationManagerCompat.from(this).notify(id,nb.build());
        });

        btn3.setOnClickListener(v->{
            int id = 3;
            int requestCode = 100;
            Intent openActivityIntent  = new Intent(this,TestNotificationActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(this,
                    requestCode,
                    openActivityIntent,PendingIntent.FLAG_UPDATE_CURRENT);

            Notification n = new NotificationCompat.Builder(this,CHANNEL_ID).
                    setSmallIcon(R.drawable.msg3).setContentTitle("new mail").
                    setContentText("Read New Mail").
                    setPriority(NotificationCompat.PRIORITY_MAX).
                    setContentIntent(pendingIntent).setAutoCancel(true).build();
            NotificationManagerCompat.from(this).notify(id,n);

        });

        btn4.setOnClickListener(v->{
        int max = 100;
        int id = 4;
        //count+=10;
        NotificationCompat.Builder nb = new NotificationCompat.Builder(this,CHANNEL_ID);
          //  nb.setContentText("Download in Progerss:"+count);
            nb.setSmallIcon(R.drawable.msg4);
            nb.setPriority(NotificationCompat.PRIORITY_LOW);
            NotificationManagerCompat.from(this).notify(id,nb.build());
        Runnable run = ()->{
                for (int i = 10;i<=100;i+=10){
                    nb.setProgress(max,i,false);
                    NotificationManagerCompat.from(this).notify(id, nb.build());
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception ex){}
                }
            nb.setContentText("Complete");
            nb.setProgress(0,0,false);
            NotificationManagerCompat.from(this).notify(id,nb.build());
        };

          Thread thread = new Thread(run);
          thread.start();
        });



    }
}