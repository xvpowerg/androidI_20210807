package com.example.ch23_testnotification;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class TestNotificationActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.test_notification_layout);
    }
}
