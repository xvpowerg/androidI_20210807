package com.example.ch23_testasynctask;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private Button downloadBtn;
    private Handler handler ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         imageView = findViewById(R.id.imageView);
        downloadBtn = findViewById(R.id.downloadBtn);
        handler = new Handler();
    }


    @Override
    protected void onStart() {
        super.onStart();

        downloadBtn.setOnClickListener(v->{
         View view =  getLayoutInflater().inflate(R.layout.progress_dialog_layout,
                    null,false);
            ProgressBar bar =  view.findViewById(R.id.progressBar);
            bar.setVisibility(View.INVISIBLE);
            AlertDialog dialog =
                    new AlertDialog.Builder(this).setTitle("載入圖片").setView(view).
                            setCancelable(false).show();
            String url = "https://img.ltn.com.tw/Upload/3c/page/2021/09/06/210906-45814-1.jpg";
            ImageAsyncTask imageAsyncTask = new ImageAsyncTask(imageView,dialog,bar);
            imageAsyncTask.execute(url);

        });

    }

}