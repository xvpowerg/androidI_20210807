package com.example.ch23_testasynctask;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class ImageTool {

    static Bitmap getImage(String url){
                try(InputStream imageStream = fetch(url)){
                    BitmapDrawable bitmapDrawable =
                            (BitmapDrawable) Drawable.createFromStream(imageStream,
                                    "src");//將InputStream 傳換為 BitmapDrawable
                    return bitmapDrawable.getBitmap();
                }catch(IOException ex){
                    Log.e("Howard","IOException:"+ex);
                }

        return null;
    }

    private static InputStream fetch(String ulStr) throws IOException {
        URL url = new URL(ulStr);
        InputStream inputStream =  (InputStream)url.getContent();
        return inputStream;
    }
}
