package com.example.ch23_testasynctask;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AlertDialog;

public class ImageAsyncTask extends AsyncTask<String,Void, Bitmap> {
    private ImageView imageView;
    private AlertDialog dialog;
    private ProgressBar bar;
    public ImageAsyncTask(ImageView imageView,AlertDialog dialog, ProgressBar bar){
        this.imageView = imageView;
        this.dialog = dialog;
        this.bar = bar;
    }

    @Override
    protected void onPreExecute() {
        //UI Thread
        Log.d("Howard","onPreExecute");
        bar.setVisibility(View.VISIBLE);
    }

    @Override
    protected Bitmap doInBackground(String... urls) {
        // new Thread
        String url = urls[0];
        Bitmap bitMap = ImageTool.
                getImage(url);
        Log.d("Howard","doInBackground");
        return bitMap;
    }

    //下載之後
    @Override
    protected void onPostExecute(Bitmap bitmap) {    super.onPostExecute(bitmap);
        Log.d("Howard","onPostExecute");
        //UI Thread
        imageView.setImageBitmap(bitmap);
        bar.setVisibility(View.INVISIBLE);//隱藏ProgressBar
        dialog.dismiss();//關閉Dialog
    }
}
