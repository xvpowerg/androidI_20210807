package com.example.ch9_1_20210904_bmi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BmiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bmi_layout);
        //會接收傳入的Intent
        Intent data = getIntent();
        float height = data.getFloatExtra("height",0);
        float weight = data.getFloatExtra("weight",0);
        Log.d("Howard",height+":"+weight);
        TextView bmiMsgTxt = findViewById(R.id.bmiMsgTxt);
        TextView statusTxt = findViewById(R.id.statusTxt);
        float bmi = weight / (float)Math.pow((height/100),2);
        bmiMsgTxt.setText(String.format("%.2f",bmi));
//        String statusMsg = getString(R.string.bmi_status_danger);
//        if (bmi < 20){
//            statusMsg =getString(R.string.bmi_status_low);
//        }else if (bmi < 26){
//            statusMsg =getString(R.string.bmi_status_normal);
//        }else if(bmi < 30){
//            statusMsg =getString(R.string.bmi_status_height);
//        }else if(bmi < 40){
//            statusMsg =getString(R.string.bmi_status_too_height);
//        }

        String[] statusArray = getResources().getStringArray(R.array.bmi_status);
        String statusMsg = statusArray[statusArray.length - 1];
        if (bmi < 20){
            statusMsg = statusArray[0];
        }else if(bmi < 26){
            statusMsg = statusArray[1];
        }else if(bmi < 30){
            statusMsg = statusArray[2];
        }else if (bmi < 30){
            statusMsg = statusArray[3];
        }

        statusTxt.setText(statusMsg);
        // < 20 過低
        // < 26 正常
        //< 30 偏高
        // < 40 過高
        // 危險


    }
}
