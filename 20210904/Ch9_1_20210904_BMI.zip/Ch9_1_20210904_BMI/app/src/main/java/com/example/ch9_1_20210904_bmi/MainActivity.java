package com.example.ch9_1_20210904_bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int heightmax = 0;
    private int weightmax = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button caluBtn = findViewById(R.id.bmiCalcuBtn);
        EditText heihgtEdti = findViewById(R.id.heightEdit);
        EditText weightEdit = findViewById(R.id.weightEdit);
        heightmax = Integer.parseInt(getString(R.string.height_max));
        weightmax = Integer.parseInt(getString(R.string.weight_max));
        caluBtn.setOnClickListener(v->{
            String heightStr = heihgtEdti.getText().toString();
            String weightStr = weightEdit.getText().toString();

            try{
                if (heightStr.isEmpty() || weightStr.isEmpty()){
                    String inputError = getString(R.string.input_error);
                    throw  new IllegalArgumentException(inputError);
                }
                float height = Float.parseFloat(heightStr);
                float weight =  Float.parseFloat(weightStr);

                if (height > heightmax){

                    throw  new IllegalArgumentException(
                            String.format("%s:%s",getString(R.string.height_over_error),
                                    getString(R.string.height_max)));
                }
                if (weight > weightmax){
                    throw  new IllegalArgumentException(
                            String.format("%s:%s",getString(R.string.weight_over_error),
                                    getString(R.string.weight_max)));
                }

                Intent dataIntent = new Intent(this,BmiActivity.class);
                dataIntent.putExtra("height",height);
                dataIntent.putExtra("weight",weight);
                startActivity(dataIntent);
            }catch (Exception ex){
                Toast.makeText(this,ex.getMessage(),Toast.LENGTH_LONG).show();
            }


        });

    }
}