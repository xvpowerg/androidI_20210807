package com.example.mych9_2_20210904_bmi_mvc.app;

import android.app.Application;

import com.example.mych9_2_20210904_bmi_mvc.R;

public class MyApplication extends Application {
    public String getBmiHeightKey(){
        return getString(R.string.height_key);
    }
    public String getBmiWeightKey(){
        return getString(R.string.weight_key);
    }
}
