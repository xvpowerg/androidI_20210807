package com.example.mych9_2_20210904_bmi_mvc.tools;

import android.content.Context;

import com.example.mych9_2_20210904_bmi_mvc.R;
import com.example.mych9_2_20210904_bmi_mvc.model.Bmi;

public class BmiStatusTool {
    public static String bmiStatusToString( Context context,Bmi.BmiStatus bmiStatus) {
        switch (bmiStatus) {
            case LOW:
                return context.getString(R.string.bmi_status_low);
            case NORMAL:
                return context.getString(R.string.bmi_status_normal);
            case HEIGHT:
                return context.getString(R.string.bmi_status_height);
            case TOO_HEIGHT:
                return context.getString(R.string.bmi_status_too_height);
            case DANGER:
                return context.
                        getString(R.string.bmi_status_danger);
        }
        return "";
    }
}
