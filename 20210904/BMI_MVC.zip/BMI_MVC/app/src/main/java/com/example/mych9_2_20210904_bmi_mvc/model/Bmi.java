package com.example.mych9_2_20210904_bmi_mvc.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.function.Function;

public class Bmi implements Parcelable {
        private String height;
        private String weight;
        public enum BmiStatus{
            LOW,
            NORMAL,
            HEIGHT,
            TOO_HEIGHT,
            DANGER
        }
    //反序列化用
    //順序要注意必須跟序列化(writeToParcel)一樣
      protected  Bmi(Parcel in){
          height = in.readString();
          weight = in.readString();
      }

    public  int describeContents (){
            return 0;
    }
    //反序列化用
    public  void writeToParcel (Parcel dest,
                                int flags){
        dest.writeString(height);
        dest.writeString(weight);
    }
    public static final Creator<Bmi> CREATOR = new Creator<Bmi>() {
        @Override
        public Bmi createFromParcel(Parcel in) {
            return new Bmi(in);
        }

        @Override
        public Bmi[] newArray(int size) {
            return new Bmi[size];
        }
    };

    public Bmi(){}
    public Bmi(String height,String weight){
        this.height  = height;
        this.weight  = weight;
    }

    public String getHeight() {
        if (height == null || height.isEmpty()) return "0";
        return height;
    }

    public String getWeight() {
        if (weight == null || weight.isEmpty()) return "0";
        return weight;
    }

    public float getHeightFloat() {
        return Float.parseFloat(getHeight());
    }

    public float getWeightFloat() {
        return Float.parseFloat(getWeight());
    }

    public float calculate(){
            return calculateBmi(this.getHeightFloat(),this.getWeightFloat());
    }
    public String calculateString(int point){
        return calculateBmiString(this.getHeightFloat(),this.getWeightFloat(),point);
    }
    public String calculateString(){
        return calculateBmiString(this.getHeightFloat(),this.getWeightFloat(),2);
    }

    public static float calculateBmi(float height,float weight){
            float  bmi  = weight/(float)(Math.pow(height/100,2));
            return bmi;
    }
    public static String calculateBmiString(float height,float weight,int point){
        float bmi =  calculateBmi(height, weight);
        return  String.format("%."+point+"f",bmi);
    }

    /**
     *
     * @param height
     * @param weight
     * @return 預設為小數點第二位
     */
    public static String calculateBmiString(float height,float weight){
        return  calculateBmiString(height,weight,2);
    }

    public static BmiStatus getStatus(float bmi){
            BmiStatus bmiStatus = BmiStatus.LOW;
            if (bmi > 40){
                bmiStatus = BmiStatus.DANGER;
            }else if(bmi > 30){
                bmiStatus = BmiStatus.TOO_HEIGHT;
            }else if(bmi > 26){
                bmiStatus = BmiStatus.HEIGHT;
            }else if(bmi > 20){
                bmiStatus = BmiStatus.NORMAL;
            }
            return bmiStatus;
    }

    public static String getStatus(float bmi,
                                   Function<BmiStatus,String> statusMap) {
        BmiStatus bs =  getStatus(bmi);
        return statusMap.apply(bs);
    }
}
