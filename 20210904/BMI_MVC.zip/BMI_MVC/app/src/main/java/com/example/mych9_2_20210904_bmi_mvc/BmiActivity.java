package com.example.mych9_2_20210904_bmi_mvc;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mych9_2_20210904_bmi_mvc.app.MyApplication;
import com.example.mych9_2_20210904_bmi_mvc.model.Bmi;
import com.example.mych9_2_20210904_bmi_mvc.tools.BmiCalculateUI;
import com.example.mych9_2_20210904_bmi_mvc.tools.BmiStatusTool;

public class BmiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bmi_layout);
        MyApplication myApp = (MyApplication)getApplication();
            Intent dataIntent = getIntent();
        float height = dataIntent.getFloatExtra(myApp.getBmiHeightKey(),0);
        float weight =dataIntent.getFloatExtra(myApp.getBmiWeightKey(),0);
        Log.d("Howard",height+":"+weight);
        Bmi bmi = dataIntent.getParcelableExtra("bmi");

        BmiCalculateUI bmiCalculateUI = new BmiCalculateUI(this);

        bmiCalculateUI.setBmiText(bmi.calculateString());
        String status = Bmi.getStatus(bmi.calculate(),
                st->BmiStatusTool.bmiStatusToString(this,st));
        bmiCalculateUI.setStatusText(status);

//        TextView msgText = findViewById(R.id.bmiMsgTxt);
//        TextView statusText = findViewById(R.id.statusTxt);
//         msgText.setText(bmi.calculateString());
//        statusText.setText(Bmi.getStatus(bmi.calculate(),
//                st-> BmiStatusTool.bmiStatusToString(this,st)));




    }
}
