package com.example.mych9_2_20210904_bmi_mvc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import com.example.mych9_2_20210904_bmi_mvc.app.MyApplication;
import com.example.mych9_2_20210904_bmi_mvc.model.Bmi;
import com.example.mych9_2_20210904_bmi_mvc.tools.BmiStatusTool;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       EditText heightEdit =  findViewById(R.id.heightEdit);
        EditText weightEdit = findViewById(R.id.weightEdit);
        Button bmiBtn = findViewById(R.id.bmiCalcuBtn);
        MyApplication myApp = (MyApplication)getApplication();
        bmiBtn.setOnClickListener(v->{
            String height = heightEdit.getText().toString();
            String weight = weightEdit.getText().toString();
            Bmi bmi = new Bmi(height,weight);
            Intent toBmiActivity = new Intent(this,BmiActivity.class);
            //使用Intent傳基本型態
            toBmiActivity.putExtra(myApp.getBmiHeightKey(),bmi.getHeightFloat());
            toBmiActivity.putExtra(myApp.getBmiWeightKey(),bmi.getWeightFloat());
            toBmiActivity.putExtra("bmi",bmi);
            startActivity(toBmiActivity);

        // 傳參數
          // 傳Bmi
//            float bmiFloat =
//                    Bmi.calculateBmi(bmi.getHeightFloat(),bmi.getWeightFloat());
//            Bmi.BmiStatus bmiStatus =  Bmi.getStatus(bmiFloat);
//            String statusStr = Bmi.getStatus(bmiFloat,st->
//                    BmiStatusTool.bmiStatusToString(this,st));
//
//            String statusStr2 = Bmi.getStatus(bmiFloat,
//                    st->getResources().getStringArray(R.array.bmi_status)[st.ordinal()]);

        });


    }
}