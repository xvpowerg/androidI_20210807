package com.example.mych9_2_20210904_bmi_mvc.tools;

import android.content.Context;
import android.widget.TextView;

import com.example.mych9_2_20210904_bmi_mvc.BmiActivity;
import com.example.mych9_2_20210904_bmi_mvc.R;

import org.w3c.dom.Text;

public class BmiCalculateUI {
        private BmiActivity bmiActivity;
        private TextView bmiView;
        private TextView statusView;
        public BmiCalculateUI(BmiActivity bmiActivity){
            statusView = bmiActivity.findViewById(R.id.statusTxt);
            bmiView = bmiActivity.findViewById(R.id.bmiMsgTxt);
        }

        public void setStatusText(String status){
                this.statusView.setText(status);
        }
        public void setBmiText(String bmi){
            this.bmiView.setText(bmi);
        }

    public String getStatusText(){
        return this.statusView.getText().toString();
    }
    public String getBmiText(){
            return this.bmiView.getText().toString();
    }

}
