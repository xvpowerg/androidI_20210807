package com.example.ch19_2_sprinner2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Optional;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private  Spinner spinnerCountry;
    private ArrayList<String[]> countryNameList = new ArrayList<>();
    private int cityPosition = 0;
    //每次都會建立Adapter
    private void plan1(int position){
        String[] countryArray = countryNameList.get(position);
        ArrayAdapter<String> countryAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,countryArray);
        spinnerCountry.setAdapter(countryAdapter);
    }
    private void plan2(int position){
        String[] countryArray = countryNameList.get(position);
        ArrayAdapter<String> stringArrayAdapter = (ArrayAdapter)spinnerCountry.getAdapter();
        Optional<ArrayAdapter<String>> arrayAdapterOp = Optional.ofNullable(stringArrayAdapter);
        stringArrayAdapter =  arrayAdapterOp.orElseGet(()->{
                ArrayAdapter<String> newArraryAdapter = new ArrayAdapter(this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1);
            spinnerCountry.setAdapter(newArraryAdapter);
            return newArraryAdapter;
        });
        stringArrayAdapter.clear();
        stringArrayAdapter.addAll(countryArray);
    }

    private void initCountryList(){
        countryNameList.add(getResources().getStringArray(R.array.country_0));
        countryNameList.add(getResources().getStringArray(R.array.country_1));
        countryNameList.add(getResources().getStringArray(R.array.country_2));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initCountryList();

        Spinner spinnerCity = findViewById(R.id.spinner_city);
        spinnerCountry =  findViewById(R.id.spinner_country);
        TextView cityName = findViewById(R.id.city_name);


        String[] cities = getResources().getStringArray(R.array.cities);
        ArrayAdapter<String> cityAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,cities);
        spinnerCity.setAdapter(cityAdapter);

        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long id) {
//                Log.d("Howard","adapterView:"+adapterView);
//                Log.d("Howard","view:"+view);
//                Log.d("Howard","pos:"+pos);
//                Log.d("Howard","id:"+id);
                cityName.setText(cities[pos]);
                cityPosition = pos;
                //plan1(pos);
                plan2(pos);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
               String[] name = countryNameList.get(cityPosition);
                Toast.makeText(MainActivity.this,
                        name[pos], Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}