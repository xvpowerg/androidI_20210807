package com.example.ch20_1_completetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
private String[] imageString = new String[9];

private void initArray(){
    String image = "image";
    for(int i = 1; i <= imageString.length;i++){
        imageString[i-1] = image+i;
    }

}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initArray();
        AutoCompleteTextView auct =  findViewById(R.id.imageCT);
        ImageView userImv =  findViewById(R.id.userImageView);
        ArrayAdapter<String> adapter = new ArrayAdapter(this,
                android.R.layout.simple_dropdown_item_1line,
                android.R.id.text1,imageString);
        auct.setAdapter(adapter);
        auct.setThreshold(1);
        auct.setOnItemClickListener((parent,view,position,id)->{
            Log.d("Howard","parent:"+parent);
            Log.d("Howard","view:"+view);
           String name =  parent.getItemAtPosition(position).toString();
          int resId =
                  getResources().getIdentifier(name,"drawable",getPackageName());

            userImv.setImageResource(resId);
        });


    }
}