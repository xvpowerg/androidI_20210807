package com.example.ch20_2_listview1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = findViewById(R.id.myListView);
        ListView listView2 = findViewById(R.id.myListView2);
        ListView listView3 = findViewById(R.id.myListView3);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Ken");
        arrayList.add("Vivin");
        arrayList.add("Lindy");
        arrayList.add("Joy");

        ArrayList<Integer> ageList = new ArrayList<>();
        ageList.add(18);
        ageList.add(25);
        ageList.add(13);
        ageList.add(2);


        ArrayList<Integer> imageIdList = new ArrayList<>();
        imageIdList.add(R.drawable.image1);
        imageIdList.add(R.drawable.image2);
        imageIdList.add(R.drawable.image3);
        imageIdList.add(R.drawable.image4);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,arrayList);
        listView.setAdapter(arrayAdapter);
        List<Map<String,Object>> datas = new ArrayList<>();
        for (int i = 0;i <arrayList.size();i++){
            String name = arrayList.get(i);
            int age = ageList.get(i);
            Map<String,Object> map = new HashMap();
            map.put("name",name);
            map.put("age",age);
            datas.add(map);
        }

        String[] from = {"name","age"};
        int[] to = {R.id.user_name_txt,
                R.id.user_age_txt};
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,
                datas,
                R.layout.simple_list_view_layout,
                from, to);
        listView2.setAdapter(simpleAdapter);

        List<Map<String,Object>> dataList2 = new ArrayList<>();

        for (int i = 0;i<arrayList.size();i++){
            String name = arrayList.get(i);
            int imgResId = imageIdList.get(i);
            Map<String,Object> map = new HashMap<>();
            map.put("name",name);
            map.put("imgId",imgResId);
            dataList2.add(map);
        }
        String[] from2 ={"name","imgId"};
        int[] to2 ={R.id.nameTxtView,R.id.userImageView};
        SimpleAdapter simpleAdapter2 = new SimpleAdapter(this,
                dataList2,
                R.layout.simple_list_view_image_laouyt,
                from2,
                to2);

        listView3.setAdapter(simpleAdapter2);
    }
}