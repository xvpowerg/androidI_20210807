package com.example.ch19_1_adapter_spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner spinner2 = findViewById(R.id.spinner2);
        Spinner spinner3 = findViewById(R.id.spinner3);

        String[] cities = getResources().getStringArray(R.array.cities);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(this,
                android.R.layout.simple_expandable_list_item_1,
                android.R.id.text1,cities);
        spinner2.setAdapter(arrayAdapter);

        ArrayAdapter<String> arrayAdapter3 = new ArrayAdapter(this,
                R.layout.my_city_spinner_layout,
                R.id.cityNameText,
                cities);
        spinner3.setAdapter(arrayAdapter3);



    }
}