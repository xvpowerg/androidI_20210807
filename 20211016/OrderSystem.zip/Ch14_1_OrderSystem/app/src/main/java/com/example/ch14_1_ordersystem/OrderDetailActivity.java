package com.example.ch14_1_ordersystem;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ch14_1_ordersystem.bean.Item;
import com.example.ch14_1_ordersystem.bean.Order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDetailActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_detail_layout);
        Order order = getIntent().getParcelableExtra("order");
          TextView totalTxt =   findViewById(R.id.totalTxt);
          ListView orderListView = findViewById(R.id.orderDetailListView);
        int total = order.getTotal();
        totalTxt.setText("Total:"+total);
        List<Map<String,Object>> dataList = new ArrayList<>();
        String[] from = {"name","count","price"};
        int[] to = {R.id.nameTxt,R.id.countTxt,R.id.priceTxt};
        Map<String,Object> title = new HashMap<>();
        title.put("name","品名");
        title.put("count","數量");
        title.put("price","金額");
        dataList.add(title);

        ArrayList<Item> items = order.getItem();
        for (Item item : items){
            String name = item.getName();
            String count = item.getCount()+"";
            String price = item.getPrice()+"";
            Map<String,Object> dataMap = new HashMap<>();
            dataMap.put("name",name);
            dataMap.put("count",count);
            dataMap.put("price",price);
            dataList.add(dataMap);
        }
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,dataList,
                R.layout.sa_order_detail_layout,from,to);
        orderListView.setAdapter(simpleAdapter);
//        TextView detailView = findViewById(R.id.detailView);
//        detailView.setText(order.toString());
    }
}

