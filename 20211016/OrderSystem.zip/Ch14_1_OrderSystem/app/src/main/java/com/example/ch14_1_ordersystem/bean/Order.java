package com.example.ch14_1_ordersystem.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Arrays;
import  java.util.function.Consumer;
import java.util.function.Predicate;

public class Order  implements Parcelable {
    private ArrayList<Item> items = new ArrayList<>();
    private Category category;
    private String[] categoryStrs;

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel parcel) {
            return new Order(parcel);
        }
        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    protected Order(Parcel in){
        items = in.createTypedArrayList(Item.CREATOR);
        categoryStrs =  in.createStringArray();
        //透過字串把列舉建立
        category = Category.valueOf(in.readString());
    }
    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeTypedList(items);
        parcel.writeStringArray(categoryStrs);
        parcel.writeString(category.name());
    }

    public enum Category{
        Internal,
        Takeout
    }

    public Order(){ }
    public Order(String[] categoryStrs){
        this.categoryStrs = categoryStrs;
    }

    public void readItem(Consumer<Item> consumer){
        items.forEach(consumer);
    }
    //複製一份Item
    //深度copy
    public ArrayList<Item> getItem(){
        ArrayList<Item> copyList = new ArrayList();
        for (Item  tmpItem  : items){
            copyList.add((Item)tmpItem.clone());
        }
        return copyList;
    }

    public void addItem(Item item){
        items.add(item);
    }

    public void setCategory(Category category){
        this.category = category;
    }

    public Category getCategory(){
        return category;
    }

    public String getCategoryStr(){
        return categoryStrs[category.ordinal()];
    }
    public int getTotal(){
        int total = 0;
        for (Item item : items){
            total += item.getCount() * item.getPrice();
        }
        return total;
    }


    @Override
    public String toString() {
        return "Order{" +
                "items=" + items +
                ", category=" + category.name() +
                ", categoryStrs=" + Arrays.toString(categoryStrs) +
                '}';
    }
}
