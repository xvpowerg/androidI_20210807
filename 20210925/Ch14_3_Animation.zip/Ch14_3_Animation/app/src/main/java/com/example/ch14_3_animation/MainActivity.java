package com.example.ch14_3_animation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
       private void showDetail(View view){
           Intent toDetail = new Intent(this,DetailActivity.class);
            int type = 0;
            switch(view.getId()){
                case R.id.btn2:
                    type = 1;
                    break;
                case R.id.btn3:
                    type = 2;
                    break;
                case R.id.btn4:
                    type = 3;
                    break;
            }
           toDetail.putExtra("type",type);
            startActivity(toDetail);
       }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        btn1.setOnClickListener(this::showDetail);
        btn2.setOnClickListener(this::showDetail);
        btn3.setOnClickListener(this::showDetail);
        btn4.setOnClickListener(this::showDetail);
    }
}