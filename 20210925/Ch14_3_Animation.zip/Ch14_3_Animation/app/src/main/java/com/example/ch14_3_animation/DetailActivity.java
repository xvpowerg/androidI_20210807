package com.example.ch14_3_animation;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {
        private int[] images = {R.drawable.image1,
                R.drawable.image2,
                R.drawable.image3,
                R.drawable.image4};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);
        String[] infos = getResources().getStringArray(R.array.detail);
        Intent data =  getIntent();
        int type = data.getIntExtra("type",0);
        ImageView imageView = findViewById(R.id.roleImageView);
        TextView infoText  =  findViewById(R.id.infoText);
        imageView.setImageResource(images[type]);
        infoText.setText(infos[type]);

    }
}
