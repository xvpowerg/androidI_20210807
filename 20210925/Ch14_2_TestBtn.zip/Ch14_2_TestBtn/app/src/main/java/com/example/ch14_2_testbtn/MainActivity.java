package com.example.ch14_2_testbtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
        private void testBtnListener(View view){
                switch (view.getId()){
                    case R.id.btn1:
                        Log.d("Howard","Btn1");
                        break;
                    case R.id.btn2:
                        Log.d("Howard","Btn2");
                        break;
                    case R.id.btn3:
                        Log.d("Howard","Btn3");
                        break;
                }
        }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ToggleButton tgb =  findViewById(R.id.toggleButton);
        Switch switchBtn = findViewById(R.id.switchBtn);
        ImageView imageView = findViewById(R.id.imageView);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        btn1.setOnClickListener(this::testBtnListener);
        btn2.setOnClickListener(this::testBtnListener);
        btn3.setOnClickListener(this::testBtnListener);


         tgb.setOnCheckedChangeListener((tb,isCheck)->{
                if (isCheck){
                    imageView.setImageResource(R.drawable.image2);
                }else{
                    imageView.setImageResource(R.drawable.image1);
                }
         });


        switchBtn.setOnCheckedChangeListener((sw,isCheck)->{
            if (isCheck){
                imageView.setVisibility(View.VISIBLE);
            }else{
             //   imageView.setVisibility(View.GONE);//消失 不存在
                imageView.setVisibility(View.INVISIBLE);//隱形 看不到 但存在
            }
        });
    }
}