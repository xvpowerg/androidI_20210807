package com.example.ch14_1_testtext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Matcher;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText emailText = findViewById(R.id.myEmail);
        Button register = findViewById(R.id.registerBtn);
        register.setOnClickListener(v->{
            String email = emailText.getText().toString();
            Matcher m =  Patterns.EMAIL_ADDRESS.matcher(email);
            Log.d("Howard","Matcher:"+m);
            Log.d("Howard","Matcher:"+m.matches());
        });

    }
}