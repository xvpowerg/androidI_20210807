package com.example.ch11_implicit_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editTxt =  findViewById(R.id.msgEdit);
        Button btn = findViewById(R.id.sendMsgBtn);
        btn.setOnClickListener(v->{
            String msg = editTxt.getText().toString();
            Intent msgIntent = new Intent(this,
                    TestImplicitActivity.class);
            msgIntent.putExtra("data",msg);
            startActivity(msgIntent);

        });
    }
}