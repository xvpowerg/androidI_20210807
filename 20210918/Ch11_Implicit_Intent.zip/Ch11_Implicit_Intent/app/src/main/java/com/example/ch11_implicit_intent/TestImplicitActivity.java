package com.example.ch11_implicit_intent;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TestImplicitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.test_implicit_layout);
         TextView showText =  findViewById(R.id.showTxt);
        Intent intent = getIntent();
        String msg = intent.getStringExtra("data");
        showText.setText(msg);

        Button toUpperBtn = findViewById(R.id.toUpperBtn);
        toUpperBtn.setOnClickListener(v->{
            String upper = msg.toUpperCase();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("data",upper);
            setResult(RESULT_OK,resultIntent);
            finish();
        });
    }
}
