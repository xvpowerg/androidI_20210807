package com.example.ch12_1_take_photo;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView photoView;
    private Bitmap bitmap;
    private ActivityResultLauncher<Void> launcher =
            registerForActivityResult(new TakePhotoContract(),bmp->{
                bitmap = bmp;
                photoView.setImageBitmap(bmp);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Howard","onCreate!!");
        setContentView(R.layout.activity_main);
        photoView = findViewById(R.id.photoView);
        Button btn =  findViewById(R.id.photoBtn);
//        btn.setOnClickListener(v->{
//            Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//             startActivityForResult(it,100);
//        });

        btn.setOnClickListener(v->{
            launcher.launch( null);
        });
    }
    //恢復資料
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("Howard","onRestoreInstanceState!!");
        bitmap = savedInstanceState.getParcelable("bitmap");
        if (bitmap != null){
            photoView.setImageBitmap(bitmap);
        }
    }

    //畫面旋轉可儲存資訊
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("Howard","onSaveInstanceState!!");
        outState.putParcelable("bitmap",bitmap);
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == 100 && data != null){
//            bitmap = (Bitmap) data.getExtras().get("data");
//            photoView.setImageBitmap(bitmap);
//        }
//    }

    private class TakePhotoContract extends ActivityResultContract<Void,Bitmap>{
        @NonNull
        @Override
        public Intent createIntent(@NonNull Context context, Void input) {
            Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            return it;
        }

        @Override
        public Bitmap parseResult(int resultCode, @Nullable Intent intent) {
                    if (resultCode != RESULT_OK) return null;
            return intent.getParcelableExtra("data");
        }
    }



}