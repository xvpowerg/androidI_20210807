package com.example.ch11_4_callout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

        private String number;
    private void callPhone(){
        Uri uri = Uri.parse("tel:"+number);
        Intent intent = new Intent(Intent.ACTION_CALL,uri);
        startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText  phoneNumberEdit =  findViewById(R.id.phoneNumberEdit);
        Button btn = findViewById(R.id.callOutBtn);

        btn.setOnClickListener(v->{
            //因為要做ACTION_CALL
            // 必須先判定是否有 CALL_PHONE  permission
             number = phoneNumberEdit.getText().toString();
            Log.d("Howard","permission:1");
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.CALL_PHONE) !=
                    PackageManager.PERMISSION_GRANTED){
                Log.d("Howard","permission:2");
                //彈出授權頁面
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CALL_PHONE},
                        100);
                return;
            }

            callPhone();
        });
    }
    //彈出授權頁面後點選的了什麼狀態
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED){
            callPhone();
        }

    }
}