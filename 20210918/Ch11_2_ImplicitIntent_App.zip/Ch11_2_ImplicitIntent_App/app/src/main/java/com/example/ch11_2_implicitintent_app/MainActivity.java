package com.example.ch11_2_implicitintent_app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView resultTxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editTxt =  findViewById(R.id.msgEdit);
        Button btn = findViewById(R.id.sendMsgBtn);
        resultTxt = findViewById(R.id.resultTxt);
        btn.setOnClickListener(v->{
            String msg = editTxt.getText().toString();
            Intent msgIntent = new Intent("tw.com.showmsg");
//            Intent msgIntent = new Intent(this,
//                    TestImplicitActivity.class);
          msgIntent.putExtra("data",msg);
           //startActivity(msgIntent);
            startActivityForResult(msgIntent,100);
        });
    }


    @Override
    //requestCode 主要判定ActivityResult做什麼用的
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //resultCode 不是RESULT_OK代表 處理資料時發生錯誤
    if (resultCode != RESULT_OK){
        return;
    }
      switch(requestCode){
          case  100:
            String upperStr = data.getStringExtra("data");
            resultTxt.setText(upperStr);
           break;
        }

    }
}