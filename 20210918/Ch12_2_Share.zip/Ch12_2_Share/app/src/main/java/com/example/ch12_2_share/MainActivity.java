package com.example.ch12_2_share;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private class GalleryContract extends ActivityResultContract<Void,Uri> {
        @NonNull
        @Override
        public Intent createIntent(@NonNull Context context, Void input) {
            Intent open = new Intent();
            open.setAction(Intent.ACTION_GET_CONTENT);
            open.setType("image/*");
            return open;
        }

        @Override
        public Uri parseResult(int resultCode, @Nullable Intent intent) {
            return intent.getData();
        }
    }
    //開圖庫
    private ActivityResultLauncher<Void> luncher = registerForActivityResult(new GalleryContract(),
            uri->{
                Intent shareImageIntent = new Intent();
                shareImageIntent.setAction(Intent.ACTION_SEND);
                shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
                shareImageIntent.setType("image/*");
                startActivity(Intent.createChooser(shareImageIntent,"請選分享圖片的對象!"));

            });
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.sendBtn);
        Button shareImageBtn = findViewById(R.id.shareImageBtn);
        Button galleryBtn  = findViewById(R.id.openGalleryBtn);
        EditText msgText = findViewById(R.id.msgTxt);
        //分享文字
        btn.setOnClickListener(v->{
            String msg = msgText.getText().toString();
            Intent sendTextIntent = new Intent();
            sendTextIntent.putExtra(Intent.EXTRA_TEXT,msg);
            sendTextIntent.setAction(Intent.ACTION_SEND);
            sendTextIntent.setType("text/plain");
            startActivity(Intent.createChooser(sendTextIntent,"請選分享文字的對象!"));
        });

        shareImageBtn.setOnClickListener(v->{
            Intent sendImageIntent = new Intent();
            Uri uri = Uri.parse("android.resource://"+
                    getApplicationContext().getPackageName()+"/"+R.drawable.image2);
            sendImageIntent.setAction(Intent.ACTION_SEND);
            sendImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
            sendImageIntent.setType("image/*");
            startActivity(Intent.createChooser(sendImageIntent,"請選分享圖片的對象!"));
        });
        
        

        galleryBtn.setOnClickListener(v->{
            luncher.launch(null);
        });


    }
}