package com.example.ch11_3_implicitintent_app;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView resultTxt;
    private ActivityResultLauncher<String> luncher =
            registerForActivityResult(new UpperCaseResultContract(),
            s->resultTxt.setText(s));


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        EditText editTxt =  findViewById(R.id.msgEdit);
        Button btn = findViewById(R.id.sendMsgBtn);
        resultTxt = findViewById(R.id.resultTxt);
        btn.setOnClickListener(v->{
            Log.d("Howard","luncher:"+luncher);
            String msg = editTxt.getText().toString();
            luncher.launch(msg);
        });
    }

        //ActivityResultContract <輸入,輸出>
        //如果不需要輸入輸出的類型請輸入Void
        private class UpperCaseResultContract  extends ActivityResultContract<String,String> {
        //傳送數值 建立Intent
            @NonNull
            @Override
            public Intent createIntent(@NonNull Context context, String input) {
                Intent intent = new Intent("tw.com.showmsg");
                intent.putExtra("data",input);
                return intent;
            }
         //接收數值  Activity處理後接收數值
            @Override
            public String parseResult(int resultCode, @Nullable Intent intent) {
                if (resultCode != RESULT_OK) return null;
                return intent.getStringExtra("data");
            }
        }

}