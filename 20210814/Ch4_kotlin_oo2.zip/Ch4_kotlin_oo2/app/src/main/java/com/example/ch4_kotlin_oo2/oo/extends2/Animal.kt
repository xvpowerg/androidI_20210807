package com.example.ch4_kotlin_oo2.oo.extends2

open class Animal {
    var height:Float=0.0f
    var name:String = ""
    var age:Int=0
    constructor(){

    }
    constructor(name:String,age:Int,height:Float){
        this.name = name
        this.age = age
        this.height = height
    }
}