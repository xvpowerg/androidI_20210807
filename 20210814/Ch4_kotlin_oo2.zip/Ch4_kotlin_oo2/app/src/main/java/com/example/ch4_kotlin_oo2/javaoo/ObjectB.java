package com.example.ch4_kotlin_oo2.javaoo;

public class ObjectB  extends ObjectA{
    ObjectB(int v){
      super(v);
    }
}
