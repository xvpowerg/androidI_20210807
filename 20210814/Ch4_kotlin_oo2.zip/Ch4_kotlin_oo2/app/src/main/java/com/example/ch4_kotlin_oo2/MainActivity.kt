package com.example.ch4_kotlin_oo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.ch4_kotlin_oo2.oo.extends1.Apple
import com.example.ch4_kotlin_oo2.oo.extends1.Fruit

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val f1 = Fruit("Apple001","Green Apple",500)
        Log.d("Howard","f1:${f1.name}")
        val apple1 = Apple("Apple 0002","Red Apple",600)
//        apple1.name ="Red Apple"
//        apple1.price = 560
        Log.d("Howard","apple1:${apple1.name} ${apple1.price}")
    }
}