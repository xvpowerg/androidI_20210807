package com.example.ch4_kotlin_oo2.javaoo;

public class ObjectA {
    int v;
    ObjectA(int v){
        this.v = v;
    }
}
