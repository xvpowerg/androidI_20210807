package com.example.ch4_kotlin_oo2.oo.extends1

class Apple(id:String="",name:String="",price:Int=0): Fruit(id,name,price) {

}