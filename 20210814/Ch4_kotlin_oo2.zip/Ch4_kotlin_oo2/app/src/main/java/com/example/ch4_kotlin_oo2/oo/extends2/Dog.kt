package com.example.ch4_kotlin_oo2.oo.extends2

class Dog : Animal {
    constructor():super(){}
    constructor(name:String,age:Int,height:Float):super(name,age,height){
        this.name =name
        this.age = age
        this.height = height
    }

}