package com.example.ch4_kotlin_oo2.oo.extends1
//強制一定要使用某個建構式
//kotlin預設class都是final
open class Fruit(var id:String="" ,
                 var name:String="",
                 var price:Int=0) {

}