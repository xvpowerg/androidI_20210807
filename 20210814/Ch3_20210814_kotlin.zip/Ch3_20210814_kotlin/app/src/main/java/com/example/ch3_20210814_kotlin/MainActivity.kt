package com.example.ch3_20210814_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //testArray1()
       // testArray2()
        //testArray3()
       // testArray5()
        val tmod = TestMethod2()
        tmod.test1()
        val ans1 = tmod.test2(10,20)
        val ans2 = tmod.test2(2.5f,3.1f)
        Log.d("Howard","ans1:$ans1 ans2:$ans2")
        tmod.initBox(id="A",width = 10)
        tmod.initBox()
        tmod.initBox(20,10,"B")
        val sum1 = tmod.sum(1,2,5,6,7)
        val sum2 = tmod.sum()
        Log.d("Howard","sum1:$sum1 sum2:$sum2")

        val msg = tmod.joinNames("姓名:",".",
            "Ken","Vivin","Howard","Lucy",len = 2)
        Log.d("Howard","msg:$msg")

       val min = tmod.cmp(8,9,10,11,5,6,7)
        Log.d("Howard","min:$min")

        val scores = intArrayOf(1,2,3)
        tmod.cmp(*scores)
        val names = arrayOf<String>("Ken","Vivin","Lindy")
        tmod.printNames(*names)
    }
    fun testArray5(){
       // val intArray = arrayOf<Int>(20,50,60)
       // TestJava.foreachIntArray(intArray)
        //IntArray 基本類型Aarray
        //java使用基本型態如int  Kotlin 使用的是封箱如(Integer)
        val intArray2 = IntArray(5){it}
        TestJava.foreachIntArray(intArray2)
        val intArray3 = intArrayOf(10,20,50,60)
        TestJava.foreachIntArray(intArray3)
        val nameArray4 = arrayOf<String>("Ken","Vivin","Lindy")
        TestJava.foreachStringArray(nameArray4)

    }
    fun testArray4(){
        val defArray = Array<Int>(10){
            //產生1~99之間任意數
            Random.nextInt(1,100)
        }
         val value =  defArray.joinToString()
        Log.d("Howard","value:$value")
        defArray.sort()
        val value2 =  defArray.joinToString()
        Log.d("Howard","value2:$value2")
        //排序回新陣列 不會改變原始陣列
        //Descend 大到小
        //defArray.sortedArrayDescending()
        //defArray.sortedArray()

        //排序會改變原始陣列
        //defArray.sort()
        //defArray.sortDescending()
        val value3 = defArray.sortedArrayDescending().joinToString()
        Log.d("Howard","value3:$value3")
    }

    fun testArray3(){
        //設定Array的預設值
        val defArray = Array<String>(5){index-> "value:$index"}
        defArray.forEach { Log.d("Howard",it) }
    }


    fun testArray1(){
        val names = arrayOf("Ken","Vivin","Lindy")
        for (i in  0 until names.size ){
            Log.d("Howard","name:${names[i]}")
        }
        Log.d("Howard","==================")
        for (name in names){
            Log.d("Howard","name:${name}")
        }
        Log.d("Howard","==================")
        names.forEachIndexed { index, s ->Log.d("Howard","$index:$s")  }
    }

    fun testArray2(){
        val array0 = arrayOf(30,10,"AA",3.5)
        array0.forEach { when(it){
            is Int-> Log.d("Howard","Value is Int:")
            is String ->Log.d("Howard","Value is String:")
            else->Log.d("Howard","Error:${it.javaClass.name}")
        } }
        Log.d("Howard","=======================")
        //限定類型
        val array1 = arrayOf<Int>(30,10,17)
        var sum = 0
        array1.forEach {sum+= it}
        Log.d("Howard","sum:$sum")
    }

}