package com.example.ch3_20210814_kotlin

import android.util.Log

class TestMethod2 {

    fun test1(){
        println("Test1!!")
    }

    fun test2(a:Int,b:Int):Int{
        val ans = a*a +b*b
        return ans
    }
    fun test2(a:Float,b:Float):Float{
        val ans = a*a + b*b
        return ans
    }
    //可以給參數預設值
    fun initBox(height:Int=1,width:Int=1,id:String=""){
            Log.d("Howard",
                "Id: $id Height:$height Width:$width")
    }

    fun sum(vararg  values:Int):Int{
            var result = 0
        for (v in values){
            result += v
        }
//        values.sum()
        return result
    }
    //vararg不一定要放在最後
    //vararg 建議能放最後就放

    fun joinNames(title:String=""
                , end:String="x",
                  vararg names:String,len:Int=names.size):String{

        var  nameString =title;
        var count = 0
        for (name in names){
            if (count == len) break
            nameString+=name+" "
            count++
        }
        return nameString+end
    }

    //設計一個方法cmp
  // 1 可傳N筆整數 values
//  2 可傳入類型 cmpType 1 最大值(預設) 2 最小值
//3 回傳找到的數值

    fun cmp(vararg values:Int,cmpType:Int=1):Int{
        var tmp = 0
        if (values.isNotEmpty())  tmp =values[0]
        for (v in values){
                when(cmpType){
                    1-> if(v > tmp) tmp = v
                    2-> if(v < tmp) tmp = v
                }
        }

        return tmp
    }

    fun printNames(vararg names:String){
        names.forEach {name->
            Log.d("Howard",name) }

    }



}