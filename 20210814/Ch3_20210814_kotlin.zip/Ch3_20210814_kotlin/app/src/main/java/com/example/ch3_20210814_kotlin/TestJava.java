package com.example.ch3_20210814_kotlin;

import android.util.Log;

public class TestJava {
        public  static void foreachIntArray(int[] array){
                for (int v: array){
                    Log.d("Howard","V:"+v);
                }
        }

        public static void foreachStringArray(String[] data){
                for (String v : data){
                    Log.d("Howard","String:"+v);
                }
        }

//        public static void testVararg(int ... a,String v){
//
//        }

}
