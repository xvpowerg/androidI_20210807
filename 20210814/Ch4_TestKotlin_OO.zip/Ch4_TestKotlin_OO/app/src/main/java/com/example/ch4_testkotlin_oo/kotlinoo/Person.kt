package com.example.ch4_testkotlin_oo.kotlinoo

import android.util.Log

class Person {
    var name:String = ""
//    get(){
//        Log.d("Howard","get name:$field")
//        return field
//    }
//    set(value){
//        Log.d("Howard","set name:$value")
//        field = value
//    }
     var age:Int = 0
    lateinit var myToy:Toy
    constructor(){this.myToy = Toy()}
    constructor(name:String,age:Int){
        this.name = name
        this.age = age
        this.myToy = Toy()
    }

}