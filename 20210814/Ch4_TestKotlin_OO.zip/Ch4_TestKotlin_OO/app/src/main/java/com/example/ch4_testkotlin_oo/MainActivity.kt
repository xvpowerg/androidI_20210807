package com.example.ch4_testkotlin_oo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.ch4_testkotlin_oo.javaoo.Student
import com.example.ch4_testkotlin_oo.kotlinoo.Person
import java.time.LocalDateTime
import java.util.stream.Stream

class MainActivity : AppCompatActivity() {
    var dataTile:LocalDateTime = LocalDateTime.now()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val p = Person("Ken",26)
        Log.d("Howard","name:${p.name} " +
                "age:${p.age}")

        val obj1 = Person()
        //回傳目前物件
        //it表示目前物件
        //每一個also 可在串接下一個標設定物件
       obj1.also {
           this.dataTile
            it.age=15
        }.also {
            it.name = "Lucy"
       }
        Log.d("Howard","name:${obj1.name} " +
                "age:${obj1.age}")
        //回傳目前物件
        //this表示目前物件
        //如果不需要使用this表示其他物件時
        //每一個apply 可在串接下一個標設定物件
        val obj2= Person()
        obj2.apply { 
            name="Joy"
            age = 26
        }
        Log.d("Howard","name:${obj2.name} " +
                "age:${obj2.age}")

        val obj3= Person()
        Log.d("Howard","name:${obj3.name} " +
                "age:${obj3.age} Toy:${obj3.myToy.name}")
        //回傳最後一個數值
        //it表示目前物件
        //如果不需要使用this表示其他物件時
        obj3.let {
            it.name = "Iris"
            it.age = 2
            it.myToy//回傳
        }.apply {
            price = 80
            name="芭比!"
        }
        Log.d("Howard","name:${obj3.name} " +
                "age:${obj3.age} Toy:${obj3.myToy.name}")

        //回傳最後一個數值
        //this表示目前物件
        //如果不需要使用this表示其他物件時
        val obj4= Person()
        val pass = obj4.run {
            name = "Bon"
            age = 15//可能由資料庫抓取 雲端
            age >=18
        }
        if (pass){
            Log.d("Howard","過關")
        }else{
            Log.d("Howard","未過關")
        }
        val obj5= Person()
        //回傳最後一個數值
        //可傳一組參數作為設定this的依據
        //this表示目前物件
        //如果不需要使用this表示其他物件時
        val stObj =  with(obj5){
            name = "join"
            age = 82
            this
        }
        Log.d("Howard","name:${stObj.name} " +
                "age:${stObj.age} ")
    }
}