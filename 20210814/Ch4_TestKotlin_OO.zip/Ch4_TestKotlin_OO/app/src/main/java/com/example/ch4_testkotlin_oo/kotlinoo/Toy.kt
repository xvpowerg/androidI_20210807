package com.example.ch4_testkotlin_oo.kotlinoo

 class Toy {
    var price:Int = 0
    var name:String = ""
     constructor(){}
     constructor(price: Int, name: String) {
         this.price = price
         this.name = name
     }

 }